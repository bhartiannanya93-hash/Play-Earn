package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Play & Earn", appName)
  }

  @Test
  fun `arrow puzzle generator creates valid solvable puzzle`() {
    for (level in 1..10) {
      val (gridSize, tiles) = com.example.ui.screens.generateSolvablePuzzle(level)
      assert(tiles.isNotEmpty()) { "Level $level produced empty tiles" }
      assert(!com.example.ui.screens.hasDirectlyFacingAdjacentArrows(tiles)) {
        "Level $level has directly facing adjacent arrows"
      }
      assert(!com.example.ui.screens.hasHeadOnCollisions(tiles)) {
        "Level $level has head on collisions"
      }
      assert(com.example.ui.screens.isBoard100PercentSolvable(gridSize, tiles)) {
        "Level $level is not 100 percent solvable"
      }
    }
  }

  @Test
  fun `coin to rupee calculation rate is strictly 100 coins to 1 rupee`() {
    val formatRupee: (Int) -> String = { coins ->
      String.format(java.util.Locale.US, "₹%.2f", coins / 100.0)
    }
    assertEquals("₹0.11", formatRupee(11))
    assertEquals("₹0.04", formatRupee(4))
    assertEquals("₹0.12", formatRupee(12))
    assertEquals("₹2.05", formatRupee(205))
  }

  @Test
  fun `referral bonus values match rules`() {
    val referrerCoins = 1000
    val referrerRupees = referrerCoins / 100.0
    val refereeCoins = 500
    val refereeRupees = refereeCoins / 100.0

    assertEquals(10.00, referrerRupees, 0.001)
    assertEquals(5.00, refereeRupees, 0.001)
    assertEquals(1000, referrerCoins)
    assertEquals(500, refereeCoins)
  }

  @Test
  fun `ad config duration is standard 15 seconds full length rewarded video`() {
    assertEquals(15, com.example.ads.AdConfig.REWARDED_AD_DURATION_SECONDS)
  }

  @Test
  fun `level completion ad verification strictly gates reward on both reward earned and ad dismissed`() {
    var rewardCredited = false
    var userEarnedReward = false

    // Simulation 1: User skips early
    userEarnedReward = false
    val adDismissedEarly = false // user dismissed without completion
    if (adDismissedEarly && userEarnedReward) {
      rewardCredited = true
    }
    assertEquals(false, rewardCredited)

    // Simulation 2: User completes full video
    userEarnedReward = true
    val adDismissedAfterReward = true
    if (adDismissedAfterReward && userEarnedReward) {
      rewardCredited = true
    }
    assertEquals(true, rewardCredited)
  }

  @Test
  fun `random coin rewards for level completion are within 1 to 50 coins`() {
    for (i in 1..100) {
      val coins = (1..50).random()
      assert(coins in 1..50) { "Coins $coins out of bounds 1..50" }
    }
  }
}
