package com.example

import com.example.util.PasswordUtils
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun passwordHashing_isConsistent() {
    val hash1 = PasswordUtils.hashPassword("mySecretPassword123")
    val hash2 = PasswordUtils.hashPassword("mySecretPassword123")
    assertEquals(hash1, hash2)
    assertTrue(hash1.isNotBlank())
  }

  @Test
  fun passwordVerification_correctPassword_returnsTrue() {
    val rawPassword = "securePassword!99"
    val hash = PasswordUtils.hashPassword(rawPassword)
    assertTrue(PasswordUtils.verifyPassword(rawPassword, hash))
  }

  @Test
  fun passwordVerification_wrongPassword_returnsFalse() {
    val rawPassword = "securePassword!99"
    val hash = PasswordUtils.hashPassword(rawPassword)
    assertFalse(PasswordUtils.verifyPassword("randomWrongPass", hash))
    assertFalse(PasswordUtils.verifyPassword("securepassword!99", hash)) // case sensitive
    assertFalse(PasswordUtils.verifyPassword("123456", hash))
  }

  @Test
  fun passwordVerification_emptyInputs_returnsFalse() {
    val hash = PasswordUtils.hashPassword("test")
    assertFalse(PasswordUtils.verifyPassword("", hash))
    assertFalse(PasswordUtils.verifyPassword("   ", hash))
    assertFalse(PasswordUtils.verifyPassword("test", null))
    assertFalse(PasswordUtils.verifyPassword("test", ""))
  }

  @Test
  fun hybridVerification_sha256HashMatch() {
    val rawPassword = "myUserPass#2024"
    val hash = PasswordUtils.hashPassword(rawPassword)
    val result = PasswordUtils.verifyPasswordHybrid(rawPassword, hash)
    assertEquals(PasswordUtils.VerifyResult.HASH_MATCH, result)
    assertTrue(PasswordUtils.verifyPassword(rawPassword, hash))
  }

  @Test
  fun hybridVerification_plaintextMatch_forOlderAccounts() {
    val rawPassword = "legacyPlainPassword"
    // Stored password is raw plaintext in an older account
    val storedLegacyPassword = "legacyPlainPassword"
    val result = PasswordUtils.verifyPasswordHybrid(rawPassword, storedLegacyPassword)
    assertEquals(PasswordUtils.VerifyResult.PLAINTEXT_MATCH, result)
    assertTrue(PasswordUtils.verifyPassword(rawPassword, storedLegacyPassword))
  }

  @Test
  fun hybridVerification_mismatch_returnsMismatch() {
    val result = PasswordUtils.verifyPasswordHybrid("wrongPass", "storedPlainPass")
    assertEquals(PasswordUtils.VerifyResult.MISMATCH, result)
    assertFalse(PasswordUtils.verifyPassword("wrongPass", "storedPlainPass"))
  }
}

