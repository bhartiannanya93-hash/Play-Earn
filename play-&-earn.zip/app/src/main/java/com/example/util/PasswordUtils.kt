package com.example.util

import java.security.MessageDigest

object PasswordUtils {
    enum class VerifyResult {
        MISMATCH,
        HASH_MATCH,
        PLAINTEXT_MATCH
    }

    /**
     * Hashes a plain-text password using SHA-256 for secure local and remote comparison.
     */
    fun hashPassword(password: String): String {
        if (password.isBlank()) return ""
        val digest = MessageDigest.getInstance("SHA-256")
        val hashBytes = digest.digest(password.trim().toByteArray(Charsets.UTF_8))
        return hashBytes.joinToString("") { "%02x".format(it) }
    }

    /**
     * Hybrid password verification:
     * a) Checks if the SHA-256 hash of the entered password matches the stored password.
     * b) Checks if the raw/plaintext entered password directly matches the stored password (for older accounts).
     *
     * Returns:
     * - HASH_MATCH if SHA-256 hash matched
     * - PLAINTEXT_MATCH if raw/plaintext matched
     * - MISMATCH otherwise
     */
    fun verifyPasswordHybrid(enteredPassword: String, storedHashOrPassword: String?): VerifyResult {
        if (enteredPassword.isBlank() || storedHashOrPassword.isNullOrBlank()) {
            return VerifyResult.MISMATCH
        }
        val cleanEntered = enteredPassword.trim()
        val cleanStored = storedHashOrPassword.trim()
        val hashedEntered = hashPassword(cleanEntered)

        // a) SHA-256 hash of input matches stored password
        if (cleanStored.equals(hashedEntered, ignoreCase = true)) {
            return VerifyResult.HASH_MATCH
        }

        // b) Raw/plaintext input directly matches stored password (for older accounts)
        if (cleanStored == cleanEntered) {
            return VerifyResult.PLAINTEXT_MATCH
        }

        return VerifyResult.MISMATCH
    }

    /**
     * Verifies an entered password against a stored password hash or legacy password.
     * Returns true if either SHA-256 hash or raw/plaintext matches.
     */
    fun verifyPassword(enteredPassword: String, storedHashOrPassword: String?): Boolean {
        val result = verifyPasswordHybrid(enteredPassword, storedHashOrPassword)
        return result == VerifyResult.HASH_MATCH || result == VerifyResult.PLAINTEXT_MATCH
    }
}
