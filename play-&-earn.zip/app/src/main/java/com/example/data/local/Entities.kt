package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey
    val id: String = "user_default_1",
    val name: String = "Suman Kumar",
    val email: String = "user@playearn.app",
    val phone: String = "+91 98765 43210",
    val avatarIndex: Int = 0,
    val referralCode: String = "EARN789",
    val referredBy: String? = null,
    val isAdmin: Boolean = false,
    val isBlocked: Boolean = false,
    val passwordHash: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "wallets")
data class WalletEntity(
    @PrimaryKey
    val userId: String = "user_default_1",
    val balanceCoins: Int = 1255,
    val balanceRupees: Double = 12.55,
    val todayEarnedRupees: Double = 20.00,
    val totalEarnedRupees: Double = 450.00,
    val pendingWithdrawalRupees: Double = 0.00,
    val totalWithdrawnRupees: Double = 300.00,
    val lastUpdatedDate: String = ""
)

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey
    val id: String,
    val userId: String,
    val type: String, // "GAME", "AD", "TASK", "CHECKIN", "REFERRAL", "WITHDRAWAL"
    val title: String,
    val subtitle: String,
    val amountRupees: Double,
    val amountCoins: Int,
    val isCredit: Boolean,
    val status: String, // "COMPLETED", "PENDING", "APPROVED", "REJECTED", "PAID"
    val timestamp: Long = System.currentTimeMillis(),
    val referenceId: String = ""
)

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey
    val id: String,
    val title: String,
    val description: String,
    val rewardCoins: Int,
    val rewardRupees: Double,
    val category: String, // "DAILY", "GAME", "AD", "SPECIAL"
    val isRepeatable: Boolean = false,
    val isCompleted: Boolean = false,
    val lastCompletedDate: String = "",
    val iconType: String = "checkin", // "game", "ad", "checkin", "level", "challenge"
    val actionRoute: String = "home",
    val currentProgress: Int = 0,
    val targetProgress: Int = 1,
    val isEnabled: Boolean = true
)

@Entity(tableName = "game_progress")
data class GameProgressEntity(
    @PrimaryKey
    val key: String, // "userId_gameId"
    val userId: String,
    val gameId: String, // "tap_coin", "color_match", "catch_candy"
    val currentLevel: Int = 1,
    val highScore: Int = 0,
    val totalPlays: Int = 0,
    val lastPlayedTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "withdrawals")
data class WithdrawalEntity(
    @PrimaryKey
    val id: String,
    val userId: String,
    val userName: String,
    val amountRupees: Double,
    val paymentMethod: String, // "UPI", "BANK"
    val accountHolder: String,
    val upiOrAccount: String,
    val ifsc: String = "",
    val status: String, // "PENDING", "APPROVED", "REJECTED", "PAID"
    val requestTimestamp: Long = System.currentTimeMillis(),
    val processedTimestamp: Long? = null,
    val adminNote: String = ""
)

@Entity(tableName = "app_config")
data class AppConfigEntity(
    @PrimaryKey
    val id: Int = 1,
    val minWithdrawalRupees: Double = 50.0,
    val coinToRupeeRate: Double = 0.01, // 100 coins = ₹1.00
    val tapCoinRewardCoins: Int = 5,
    val colorMatchRewardCoins: Int = 5,
    val catchCandyRewardCoins: Int = 5,
    val adRewardCoins: Int = 3,
    val checkinRewardCoins: Int = 2,
    val referralBonusRupees: Double = 10.0,
    val isTapCoinEnabled: Boolean = true,
    val isColorMatchEnabled: Boolean = true,
    val isCatchCandyEnabled: Boolean = true,
    val maintenanceMode: Boolean = false
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey
    val id: String,
    val userId: String,
    val title: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)
