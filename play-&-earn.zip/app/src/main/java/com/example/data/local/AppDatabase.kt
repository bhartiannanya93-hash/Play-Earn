package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.util.PasswordUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        UserEntity::class,
        WalletEntity::class,
        TransactionEntity::class,
        TaskEntity::class,
        GameProgressEntity::class,
        WithdrawalEntity::class,
        AppConfigEntity::class,
        NotificationEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun walletDao(): WalletDao
    abstract fun transactionDao(): TransactionDao
    abstract fun taskDao(): TaskDao
    abstract fun gameProgressDao(): GameProgressDao
    abstract fun withdrawalDao(): WithdrawalDao
    abstract fun appConfigDao(): AppConfigDao
    abstract fun notificationDao(): NotificationDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "play_and_earn_db"
                )
                    .addCallback(DatabaseCallback())
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        populateInitialData(database)
                    }
                }
            }
        }

        suspend fun populateInitialData(database: AppDatabase) {
            val defaultUserId = "user_default_1"
            
            // 1. Initial User
            val defaultUser = UserEntity(
                id = defaultUserId,
                name = "Suman Kumar",
                email = "suman@playearn.app",
                phone = "+91 98765 43210",
                avatarIndex = 0,
                referralCode = "EARN789",
                isAdmin = true,
                passwordHash = PasswordUtils.hashPassword("password123")
            )
            database.userDao().insertUser(defaultUser)

            // 2. Initial Wallet with exact values: 1255 coins = ₹12.55, ₹1.00 today, ₹12.55 total
            val defaultWallet = WalletEntity(
                userId = defaultUserId,
                balanceCoins = 1255,
                balanceRupees = 12.55,
                todayEarnedRupees = 1.00,
                totalEarnedRupees = 12.55,
                pendingWithdrawalRupees = 0.00,
                totalWithdrawnRupees = 50.00
            )
            database.walletDao().insertOrUpdateWallet(defaultWallet)

            // 3. Initial App Configuration
            val initialConfig = AppConfigEntity(
                id = 1,
                minWithdrawalRupees = 50.0,
                coinToRupeeRate = 0.01,
                tapCoinRewardCoins = 5,
                colorMatchRewardCoins = 5,
                catchCandyRewardCoins = 5,
                adRewardCoins = 3,
                checkinRewardCoins = 2,
                referralBonusRupees = 10.0,
                isTapCoinEnabled = true,
                isColorMatchEnabled = true,
                isCatchCandyEnabled = true
            )
            database.appConfigDao().saveAppConfig(initialConfig)

            // 4. Initial Daily Tasks according to PRD
            val initialTasks = listOf(
                TaskEntity(
                    id = "task_play_game",
                    title = "Play Game",
                    description = "Play and earn coins",
                    rewardCoins = 5,
                    rewardRupees = 0.50,
                    category = "DAILY",
                    isRepeatable = true,
                    iconType = "game",
                    actionRoute = "game"
                ),
                TaskEntity(
                    id = "task_watch_ad",
                    title = "Watch Ad",
                    description = "Watch video and earn",
                    rewardCoins = 3,
                    rewardRupees = 0.30,
                    category = "DAILY",
                    isRepeatable = true,
                    iconType = "ad",
                    actionRoute = "task"
                ),
                TaskEntity(
                    id = "task_daily_checkin",
                    title = "Daily Check-in",
                    description = "Daily check-in bonus",
                    rewardCoins = 2,
                    rewardRupees = 0.20,
                    category = "DAILY",
                    isRepeatable = false,
                    iconType = "checkin",
                    actionRoute = "task"
                )
            )
            database.taskDao().insertTasks(initialTasks)

            // 5. Initial Game Progress
            database.gameProgressDao().saveGameProgress(
                GameProgressEntity(
                    key = "${defaultUserId}_tap_coin",
                    userId = defaultUserId,
                    gameId = "tap_coin",
                    currentLevel = 25,
                    highScore = 250,
                    totalPlays = 34
                )
            )
            database.gameProgressDao().saveGameProgress(
                GameProgressEntity(
                    key = "${defaultUserId}_color_match",
                    userId = defaultUserId,
                    gameId = "color_match",
                    currentLevel = 12,
                    highScore = 180,
                    totalPlays = 22
                )
            )
            database.gameProgressDao().saveGameProgress(
                GameProgressEntity(
                    key = "${defaultUserId}_catch_candy",
                    userId = defaultUserId,
                    gameId = "catch_candy",
                    currentLevel = 8,
                    highScore = 95,
                    totalPlays = 15
                )
            )
            database.gameProgressDao().saveGameProgress(
                GameProgressEntity(
                    key = "${defaultUserId}_arrow_escape",
                    userId = defaultUserId,
                    gameId = "arrow_escape",
                    currentLevel = 1,
                    highScore = 0,
                    totalPlays = 0
                )
            )

            // 6. Initial Transactions as in PRD
            val now = System.currentTimeMillis()
            val initialTransactions = listOf(
                TransactionEntity(
                    id = "TXN_78491",
                    userId = defaultUserId,
                    type = "GAME",
                    title = "Game Reward",
                    subtitle = "Level Complete (Tap Coin)",
                    amountRupees = 0.50,
                    amountCoins = 50,
                    isCredit = true,
                    status = "COMPLETED",
                    timestamp = now - 1800000
                ),
                TransactionEntity(
                    id = "TXN_78490",
                    userId = defaultUserId,
                    type = "AD",
                    title = "Watch Ad Reward",
                    subtitle = "Rewarded Video Completed",
                    amountRupees = 0.30,
                    amountCoins = 30,
                    isCredit = true,
                    status = "COMPLETED",
                    timestamp = now - 7200000
                ),
                TransactionEntity(
                    id = "TXN_78489",
                    userId = defaultUserId,
                    type = "CHECKIN",
                    title = "Daily Check-in",
                    subtitle = "Day 1 Streak Bonus",
                    amountRupees = 0.20,
                    amountCoins = 20,
                    isCredit = true,
                    status = "COMPLETED",
                    timestamp = now - 28800000
                ),
                TransactionEntity(
                    id = "TXN_78480",
                    userId = defaultUserId,
                    type = "WITHDRAWAL",
                    title = "Withdrawal",
                    subtitle = "UPI Transfer to user@okhdfcbank",
                    amountRupees = 50.00,
                    amountCoins = 5000,
                    isCredit = false,
                    status = "APPROVED",
                    timestamp = now - 86400000
                )
            )
            for (txn in initialTransactions) {
                database.transactionDao().insertTransaction(txn)
            }

            // 7. Initial Notifications
            database.notificationDao().insertNotification(
                NotificationEntity(
                    id = "notif_welcome",
                    userId = defaultUserId,
                    title = "Welcome to Play & Earn! 🎉",
                    message = "Play games, complete daily tasks, and withdraw instant real rewards!",
                    timestamp = now
                )
            )
            database.notificationDao().insertNotification(
                NotificationEntity(
                    id = "notif_bonus",
                    userId = defaultUserId,
                    title = "Daily Bonus Active ⚡",
                    message = "Claim your daily check-in coins now and start earning!",
                    timestamp = now - 3600000
                )
            )
        }
    }
}
