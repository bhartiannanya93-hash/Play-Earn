package com.example.data.repository

import com.example.data.local.*
import com.example.util.PasswordUtils
import com.google.android.gms.tasks.Tasks
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class RewardsRepository(private val database: AppDatabase) {

    private val userDao = database.userDao()
    private val walletDao = database.walletDao()
    private val transactionDao = database.transactionDao()
    private val taskDao = database.taskDao()
    private val gameProgressDao = database.gameProgressDao()
    private val withdrawalDao = database.withdrawalDao()
    private val appConfigDao = database.appConfigDao()
    private val notificationDao = database.notificationDao()

    private val coroutineScope = CoroutineScope(Dispatchers.IO)

    // Active Firestore snapshot listener registrations
    private var transactionListener: ListenerRegistration? = null
    private var walletListener: ListenerRegistration? = null
    private var withdrawalListener: ListenerRegistration? = null
    private var gameProgressListener: ListenerRegistration? = null
    private var currentListeningUserId: String? = null

    // Firebase Firestore and Auth instances
    private val firestore: FirebaseFirestore? by lazy {
        try {
            FirebaseFirestore.getInstance()
        } catch (e: Exception) {
            null
        }
    }

    private val firebaseAuth: FirebaseAuth? by lazy {
        try {
            FirebaseAuth.getInstance()
        } catch (e: Exception) {
            null
        }
    }

    init {
        coroutineScope.launch {
            try {
                taskDao.deleteTask("task_complete_level")
                taskDao.deleteTask("task_daily_challenge")
            } catch (e: Exception) {
                // Ignore cleanup error
            }

            // Normalize AppConfig to 100 coins = ₹1 (0.01), minWithdrawalRupees = 50.0, and referralBonusRupees = 10.0
            try {
                val cfg = appConfigDao.getAppConfigDirect()
                if (cfg != null && (cfg.coinToRupeeRate != 0.01 || cfg.minWithdrawalRupees != 50.0 || cfg.referralBonusRupees != 10.0)) {
                    appConfigDao.saveAppConfig(cfg.copy(coinToRupeeRate = 0.01, minWithdrawalRupees = 50.0, referralBonusRupees = 10.0))
                }
            } catch (e: Exception) {
                // Ignore
            }

            // Normalize any existing tasks to rewardRupees = rewardCoins / 100.0
            try {
                val tasks = taskDao.getAllTasks().firstOrNull() ?: emptyList()
                for (task in tasks) {
                    val correctRupees = task.rewardCoins / 100.0
                    if (Math.abs(task.rewardRupees - correctRupees) > 0.001) {
                        taskDao.updateTask(task.copy(rewardRupees = correctRupees))
                    }
                }
            } catch (e: Exception) {
                // Ignore
            }

            // Normalize any existing transactions to amountRupees = (Coins / 100.0) if amountCoins > 0
            try {
                val allTxns = transactionDao.getAllTransactions().firstOrNull() ?: emptyList()
                for (txn in allTxns) {
                    if (txn.amountCoins > 0) {
                        val correctRupees = txn.amountCoins / 100.0
                        if (Math.abs(txn.amountRupees - correctRupees) > 0.001) {
                            transactionDao.insertTransaction(txn.copy(amountRupees = correctRupees))
                        }
                    }
                }
            } catch (e: Exception) {
                // Ignore
            }

            // Normalize wallet balances
            try {
                val wallets = walletDao.getAllWallets().firstOrNull() ?: emptyList()
                for (w in wallets) {
                    val correctBalanceRupees = w.balanceCoins / 100.0
                    val txns = transactionDao.getTransactionsByUser(w.userId).firstOrNull() ?: emptyList()
                    val creditTxns = txns.filter { it.isCredit }
                    val correctTotalEarned = if (creditTxns.isNotEmpty()) {
                        creditTxns.sumOf { it.amountCoins } / 100.0
                    } else {
                        w.balanceCoins / 100.0
                    }
                    val cal = java.util.Calendar.getInstance().apply {
                        set(java.util.Calendar.HOUR_OF_DAY, 0)
                        set(java.util.Calendar.MINUTE, 0)
                        set(java.util.Calendar.SECOND, 0)
                        set(java.util.Calendar.MILLISECOND, 0)
                    }
                    val todayStart = cal.timeInMillis
                    val correctTodayEarned = if (creditTxns.isNotEmpty()) {
                        creditTxns.filter { it.timestamp >= todayStart }.sumOf { it.amountCoins } / 100.0
                    } else {
                        0.0
                    }
                    walletDao.insertOrUpdateWallet(
                        w.copy(
                            balanceRupees = correctBalanceRupees,
                            todayEarnedRupees = correctTodayEarned,
                            totalEarnedRupees = correctTotalEarned
                        )
                    )
                }
            } catch (e: Exception) {
                // Ignore
            }
        }
    }

    // ----------------------------------------------------
    // User & Session Management
    // ----------------------------------------------------
    fun getUser(userId: String): Flow<UserEntity?> = userDao.getUserById(userId)
    fun getAllUsers(): Flow<List<UserEntity>> = userDao.getAllUsers()
    fun getUserCount(): Flow<Int> = userDao.getUserCount()

    suspend fun getAutoLoginUser(): UserEntity? = withContext(Dispatchers.IO) {
        try {
            val authUser = firebaseAuth?.currentUser
            if (authUser != null) {
                val byId = userDao.getUserById(authUser.uid).firstOrNull()
                if (byId != null) return@withContext byId
                val email = authUser.email
                if (!email.isNullOrBlank()) {
                    val byEmail = userDao.getUserByEmail(email)
                    if (byEmail != null) return@withContext byEmail
                }
            }
        } catch (e: Exception) {
            // Ignore
        }
        null
    }

    suspend fun registerOrLoginUser(
        name: String,
        email: String,
        phone: String,
        password: String = "",
        referralCodeEntered: String? = null
    ): Result<UserEntity> = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim()
        val cleanPassword = password.trim()
        val isRegister = name.isNotBlank()

        if (cleanEmail.isBlank()) {
            return@withContext Result.failure(Exception("Please enter your email address."))
        }
        if (cleanPassword.isBlank()) {
            return@withContext Result.failure(Exception("Please enter your password."))
        }

        // Check for existing account on registration
        if (isRegister) {
            val existingLocal = userDao.getUserByEmail(cleanEmail)
            if (existingLocal != null) {
                return@withContext Result.failure(Exception("An account with this email already exists. Please sign in."))
            }
        }

        // 1. Firebase Authentication handling (if available)
        var firebaseUid: String? = null
        var firebaseAuthSuccess = false
        try {
            firebaseAuth?.let { auth ->
                if (cleanPassword.isNotBlank() && cleanEmail.isNotBlank()) {
                    if (isRegister) {
                        try {
                            val createResult = Tasks.await(
                                auth.createUserWithEmailAndPassword(cleanEmail, cleanPassword),
                                5, TimeUnit.SECONDS
                            )
                            firebaseUid = createResult.user?.uid
                        } catch (e: Exception) {
                            // If user already exists in Auth, sign in
                            try {
                                val signResult = Tasks.await(
                                    auth.signInWithEmailAndPassword(cleanEmail, cleanPassword),
                                    5, TimeUnit.SECONDS
                                )
                                firebaseUid = signResult.user?.uid
                            } catch (e2: Exception) {
                                // Continue with local/firestore flow
                            }
                        }
                    } else {
                        // Sign in with Firebase Auth
                        try {
                            val signResult = Tasks.await(
                                auth.signInWithEmailAndPassword(cleanEmail, cleanPassword),
                                5, TimeUnit.SECONDS
                            )
                            if (signResult.user != null) {
                                firebaseAuthSuccess = true
                                firebaseUid = signResult.user?.uid
                            }
                        } catch (e: Exception) {
                            // Firebase Auth sign-in failed
                        }
                    }
                }
            }
        } catch (e: Exception) {
            // Firebase Auth offline or unavailable
        }

        // 2. Check local Room database
        val existing = userDao.getUserByEmail(cleanEmail)
        if (existing != null) {
            if (!isRegister) {
                // Hybrid Password Verification on Login:
                // a) SHA-256 hash of input matches stored password, OR
                // b) Raw/plaintext input directly matches stored password (for older accounts).
                var passwordMatches = false
                var needsHashUpgrade = false

                if (existing.passwordHash.isNotBlank()) {
                    val checkResult = PasswordUtils.verifyPasswordHybrid(cleanPassword, existing.passwordHash)
                    when (checkResult) {
                        PasswordUtils.VerifyResult.HASH_MATCH -> {
                            passwordMatches = true
                        }
                        PasswordUtils.VerifyResult.PLAINTEXT_MATCH -> {
                            passwordMatches = true
                            needsHashUpgrade = true
                        }
                        PasswordUtils.VerifyResult.MISMATCH -> {
                            // Proceed to secondary checks
                        }
                    }
                }

                // If not matched, check Firestore record if available (e.g. account created on another device)
                if (!passwordMatches) {
                    val fs = firestore
                    if (fs != null) {
                        try {
                            val fsDoc = Tasks.await(
                                fs.collection("users").document(existing.id).get(),
                                4, TimeUnit.SECONDS
                            )
                            val fsStored = fsDoc.getString("passwordHash") ?: fsDoc.getString("password")
                            if (!fsStored.isNullOrBlank()) {
                                val fsCheck = PasswordUtils.verifyPasswordHybrid(cleanPassword, fsStored)
                                if (fsCheck == PasswordUtils.VerifyResult.HASH_MATCH) {
                                    passwordMatches = true
                                    if (existing.passwordHash != fsStored) {
                                        needsHashUpgrade = true
                                    }
                                } else if (fsCheck == PasswordUtils.VerifyResult.PLAINTEXT_MATCH) {
                                    passwordMatches = true
                                    needsHashUpgrade = true
                                }
                            }
                        } catch (e: Exception) {
                            // Ignore
                        }
                    }
                }

                // Fallback: If Firebase Auth successfully authenticated this email/password
                if (!passwordMatches && firebaseAuthSuccess) {
                    passwordMatches = true
                    needsHashUpgrade = true
                }

                // Fallback for default demo account if password was legacy
                if (!passwordMatches && cleanEmail.equals("suman@playearn.app", ignoreCase = true)) {
                    if (cleanPassword == "password123") {
                        passwordMatches = true
                        needsHashUpgrade = true
                    }
                }

                if (!passwordMatches) {
                    return@withContext Result.failure(Exception("Invalid email or password"))
                }

                // If plaintext match succeeded or hash was missing/outdated, automatically upgrade to SHA-256 hash in database
                val validUser = if (needsHashUpgrade || existing.passwordHash.isBlank()) {
                    val updated = existing.copy(passwordHash = PasswordUtils.hashPassword(cleanPassword))
                    userDao.updateUser(updated)
                    updated
                } else {
                    existing
                }

                syncUserToFirestore(validUser)
                val existingWallet = walletDao.getWalletDirect(validUser.id)
                if (existingWallet != null) {
                    syncWalletToFirestore(existingWallet)
                }
                startRealtimeListeners(validUser.id)
                return@withContext Result.success(validUser)
            } else {
                return@withContext Result.failure(Exception("An account with this email already exists. Please sign in."))
            }
        }

        // 3. Query Cloud Firestore for existing account (e.g. login on new device)
        val db = firestore
        if (db != null) {
            try {
                var firestoreUserDoc: com.google.firebase.firestore.DocumentSnapshot? = null

                // Search Firestore by email
                val emailQuery = Tasks.await(
                    db.collection("users").whereEqualTo("email", cleanEmail).limit(1).get(),
                    5, TimeUnit.SECONDS
                )
                if (!emailQuery.isEmpty) {
                    firestoreUserDoc = emailQuery.documents.firstOrNull()
                } else if (cleanEmail.lowercase() != cleanEmail) {
                    val lowerQuery = Tasks.await(
                        db.collection("users").whereEqualTo("email", cleanEmail.lowercase()).limit(1).get(),
                        5, TimeUnit.SECONDS
                    )
                    if (!lowerQuery.isEmpty) {
                        firestoreUserDoc = lowerQuery.documents.firstOrNull()
                    }
                }

                // If not found by email but we have a firebaseUid, search by document ID
                if (firestoreUserDoc == null && firebaseUid != null) {
                    val uidDoc = Tasks.await(
                        db.collection("users").document(firebaseUid!!).get(),
                        5, TimeUnit.SECONDS
                    )
                    if (uidDoc.exists()) {
                        firestoreUserDoc = uidDoc
                    }
                }

                if (firestoreUserDoc != null && firestoreUserDoc.exists()) {
                    if (isRegister) {
                        return@withContext Result.failure(Exception("An account with this email already exists. Please sign in."))
                    }

                    // Hybrid Password Verification on Firestore account:
                    // a) SHA-256 hash of input matches stored password, OR
                    // b) Raw/plaintext input directly matches stored password (for older accounts).
                    val fsStored = firestoreUserDoc.getString("passwordHash")
                        ?: firestoreUserDoc.getString("password")

                    var passwordMatches = false
                    var needsHashUpgrade = false

                    if (!fsStored.isNullOrBlank()) {
                        val fsCheck = PasswordUtils.verifyPasswordHybrid(cleanPassword, fsStored)
                        if (fsCheck == PasswordUtils.VerifyResult.HASH_MATCH) {
                            passwordMatches = true
                        } else if (fsCheck == PasswordUtils.VerifyResult.PLAINTEXT_MATCH) {
                            passwordMatches = true
                            needsHashUpgrade = true
                        }
                    } else if (firebaseAuthSuccess) {
                        passwordMatches = true
                        needsHashUpgrade = true
                    } else if (cleanEmail.equals("suman@playearn.app", ignoreCase = true)) {
                        if (cleanPassword == "password123") {
                            passwordMatches = true
                            needsHashUpgrade = true
                        }
                    }

                    if (!passwordMatches) {
                        return@withContext Result.failure(Exception("Invalid email or password"))
                    }

                    // If plaintext matched or hash missing, automatically upgrade to SHA-256 hash
                    val finalPasswordHash = if (needsHashUpgrade || fsStored.isNullOrBlank()) {
                        PasswordUtils.hashPassword(cleanPassword)
                    } else {
                        fsStored
                    }

                    val userId = firestoreUserDoc.getString("id") ?: firestoreUserDoc.id
                    val userName = firestoreUserDoc.getString("name") ?: "Player"
                    val userPhone = firestoreUserDoc.getString("phone") ?: phone.ifBlank { "+91 98765 00000" }
                    val userReferral = firestoreUserDoc.getString("referralCode") ?: ("EARN" + (100..999).random())
                    val userReferredBy = firestoreUserDoc.getString("referredBy")
                    val userIsAdmin = firestoreUserDoc.getBoolean("isAdmin") ?: false
                    val userCreatedAt = firestoreUserDoc.getLong("createdAt") ?: System.currentTimeMillis()

                    val restoredUser = UserEntity(
                        id = userId,
                        name = userName,
                        email = cleanEmail,
                        phone = userPhone,
                        referralCode = userReferral,
                        referredBy = userReferredBy,
                        isAdmin = userIsAdmin,
                        passwordHash = finalPasswordHash,
                        createdAt = userCreatedAt
                    )
                    userDao.insertUser(restoredUser)

                    // If plaintext upgrade occurred, sync updated hash back to Firestore
                    if (needsHashUpgrade) {
                        syncUserToFirestore(restoredUser)
                    }

                    // Restore Wallet from Firestore
                    try {
                        val walletSnap = Tasks.await(
                            db.collection("wallets").document(userId).get(),
                            5, TimeUnit.SECONDS
                        )
                        if (walletSnap.exists()) {
                            val coins = (walletSnap.getLong("balanceCoins") ?: 100L).toInt()
                            val rupees = coins / 100.0
                            val todayEarned = walletSnap.getDouble("todayEarnedRupees") ?: 1.00
                            val totalEarned = walletSnap.getDouble("totalEarnedRupees") ?: 1.00
                            val pending = walletSnap.getDouble("pendingWithdrawalRupees") ?: 0.0
                            val withdrawn = walletSnap.getDouble("totalWithdrawnRupees") ?: 0.0
                            val lastUpdated = walletSnap.getString("lastUpdatedDate") ?: getTodayDateString()

                            val wallet = WalletEntity(
                                userId = userId,
                                balanceCoins = coins,
                                balanceRupees = rupees,
                                todayEarnedRupees = todayEarned,
                                totalEarnedRupees = totalEarned,
                                pendingWithdrawalRupees = pending,
                                totalWithdrawnRupees = withdrawn,
                                lastUpdatedDate = lastUpdated
                            )
                            walletDao.insertOrUpdateWallet(wallet)
                        } else {
                            val defaultWallet = WalletEntity(
                                userId = userId,
                                balanceCoins = 100,
                                balanceRupees = 1.00,
                                todayEarnedRupees = 1.00,
                                totalEarnedRupees = 1.00
                            )
                            walletDao.insertOrUpdateWallet(defaultWallet)
                            syncWalletToFirestore(defaultWallet)
                        }
                    } catch (e: Exception) {
                        val localW = walletDao.getWalletDirect(userId)
                        if (localW == null) {
                            val defaultW = WalletEntity(userId = userId, balanceCoins = 100, balanceRupees = 1.00)
                            walletDao.insertOrUpdateWallet(defaultW)
                        }
                    }

                    // Restore Transactions from Firestore
                    try {
                        val txnSnap = Tasks.await(
                            db.collection("transactions").whereEqualTo("userId", userId).get(),
                            5, TimeUnit.SECONDS
                        )
                        for (tdoc in txnSnap.documents) {
                            val txn = TransactionEntity(
                                id = tdoc.getString("id") ?: tdoc.id,
                                userId = userId,
                                type = tdoc.getString("type") ?: "TASK",
                                title = tdoc.getString("title") ?: "Transaction",
                                subtitle = tdoc.getString("subtitle") ?: "",
                                amountRupees = tdoc.getDouble("amountRupees") ?: 0.0,
                                amountCoins = (tdoc.getLong("amountCoins") ?: 0L).toInt(),
                                isCredit = tdoc.getBoolean("isCredit") ?: true,
                                status = tdoc.getString("status") ?: "COMPLETED",
                                timestamp = tdoc.getLong("timestamp") ?: System.currentTimeMillis(),
                                referenceId = tdoc.getString("referenceId") ?: ""
                            )
                            transactionDao.insertTransaction(txn)
                        }
                    } catch (e: Exception) { /* continue */ }

                    // Restore Game Progress from Firestore
                    try {
                        val gpSnap = Tasks.await(
                            db.collection("game_progress").whereEqualTo("userId", userId).get(),
                            5, TimeUnit.SECONDS
                        )
                        for (gdoc in gpSnap.documents) {
                            val gameId = gdoc.getString("gameId") ?: "arrow_escape"
                            val gp = GameProgressEntity(
                                key = "${userId}_$gameId",
                                userId = userId,
                                gameId = gameId,
                                currentLevel = (gdoc.getLong("currentLevel") ?: 1L).toInt(),
                                highScore = (gdoc.getLong("highScore") ?: 0L).toInt(),
                                totalPlays = (gdoc.getLong("totalPlays") ?: 0L).toInt(),
                                lastPlayedTimestamp = gdoc.getLong("lastPlayedTimestamp") ?: System.currentTimeMillis()
                            )
                            gameProgressDao.saveGameProgress(gp)
                        }
                    } catch (e: Exception) { /* continue */ }

                    // Restore Withdrawals from Firestore
                    try {
                        val wSnap = Tasks.await(
                            db.collection("withdrawals").whereEqualTo("userId", userId).get(),
                            5, TimeUnit.SECONDS
                        )
                        for (wdoc in wSnap.documents) {
                            val w = WithdrawalEntity(
                                id = wdoc.getString("id") ?: wdoc.id,
                                userId = userId,
                                userName = wdoc.getString("userName") ?: userName,
                                amountRupees = wdoc.getDouble("amountRupees") ?: 0.0,
                                paymentMethod = wdoc.getString("paymentMethod") ?: "UPI",
                                accountHolder = wdoc.getString("accountHolder") ?: "",
                                upiOrAccount = wdoc.getString("upiOrAccount") ?: "",
                                ifsc = wdoc.getString("ifsc") ?: "",
                                status = wdoc.getString("status") ?: "PENDING",
                                requestTimestamp = wdoc.getLong("requestTimestamp") ?: System.currentTimeMillis(),
                                processedTimestamp = wdoc.getLong("processedTimestamp"),
                                adminNote = wdoc.getString("adminNote") ?: ""
                            )
                            withdrawalDao.insertWithdrawal(w)
                        }
                    } catch (e: Exception) { /* continue */ }

                    startRealtimeListeners(restoredUser.id)
                    return@withContext Result.success(restoredUser)
                }
            } catch (e: Exception) {
                // Firestore lookup failure, fallback
            }
        }

        // 4. If login mode and user was not found anywhere
        if (!isRegister) {
            return@withContext Result.failure(Exception("Invalid email or password"))
        }

        // 5. Registration flow for new user
        val generatedReferral = "EARN" + (100..999).random()
        val newUserId = firebaseUid ?: ("user_" + UUID.randomUUID().toString().substring(0, 8))
        val newUser = UserEntity(
            id = newUserId,
            name = name.ifBlank { "Player" },
            email = cleanEmail,
            phone = phone.ifBlank { "+91 98765 00000" },
            referralCode = generatedReferral,
            referredBy = referralCodeEntered?.takeIf { it.isNotBlank() },
            passwordHash = PasswordUtils.hashPassword(cleanPassword)
        )
        userDao.insertUser(newUser)
        syncUserToFirestore(newUser)

        // Check if referral code is valid
        var referrer: UserEntity? = null
        val cleanCode = referralCodeEntered?.trim()?.uppercase()
        if (!cleanCode.isNullOrBlank()) {
            referrer = userDao.getUserByReferralCode(cleanCode)
            val fs = firestore
            if (referrer == null && fs != null) {
                try {
                    val refSnap = Tasks.await(
                        fs.collection("users").whereEqualTo("referralCode", cleanCode).limit(1).get(),
                        3, TimeUnit.SECONDS
                    )
                    if (!refSnap.isEmpty) {
                        val rdoc = refSnap.documents.first()
                        val restoredReferrer = UserEntity(
                            id = rdoc.getString("id") ?: rdoc.id,
                            name = rdoc.getString("name") ?: "Player",
                            email = rdoc.getString("email") ?: "",
                            phone = rdoc.getString("phone") ?: "",
                            referralCode = rdoc.getString("referralCode") ?: cleanCode,
                            referredBy = rdoc.getString("referredBy"),
                            createdAt = rdoc.getLong("createdAt") ?: System.currentTimeMillis()
                        )
                        userDao.insertUser(restoredReferrer)
                        referrer = restoredReferrer
                    }
                } catch (e: Exception) { /* continue */ }
            }
        }

        val hasValidReferral = referrer != null
        val welcomeCoins = if (hasValidReferral) 500 else 100
        val welcomeRupees = welcomeCoins / 100.0

        // Initialize wallet for user: 500 Coins (₹5.00) with valid referral code
        val newWallet = WalletEntity(
            userId = newUserId,
            balanceCoins = welcomeCoins,
            balanceRupees = welcomeRupees,
            todayEarnedRupees = welcomeRupees,
            totalEarnedRupees = welcomeRupees
        )
        walletDao.insertOrUpdateWallet(newWallet)
        syncWalletToFirestore(newWallet)

        // Record signup bonus transaction: New User: +500 Coins (+₹5.00) "Sign-up / Welcome Bonus"
        val signupTxn = TransactionEntity(
            id = "TXN_" + UUID.randomUUID().toString().substring(0, 8).uppercase(),
            userId = newUserId,
            type = if (hasValidReferral) "REFERRAL" else "TASK",
            title = "Sign-up / Welcome Bonus",
            subtitle = if (hasValidReferral) "Referral sign-up reward (+500 Coins)" else "New account registration reward",
            amountRupees = welcomeRupees,
            amountCoins = welcomeCoins,
            isCredit = true,
            status = "COMPLETED"
        )
        transactionDao.insertTransaction(signupTxn)
        syncTransactionToFirestore(signupTxn)

        // Referrer (Inviter) receives: 1,000 Coins (₹10.00) "Referral Bonus"
        if (referrer != null) {
            creditReward(
                userId = referrer.id,
                coins = 1000,
                rupees = 10.00,
                type = "REFERRAL",
                title = "Referral Bonus",
                subtitle = "Friend ${newUser.name} joined with your code",
                refId = newUserId
            )
        }

        startRealtimeListeners(newUser.id)
        Result.success(newUser)
    }

    // ----------------------------------------------------
    // Firestore Real-Time Snapshot Listeners
    // ----------------------------------------------------
    fun startRealtimeListeners(userId: String) {
        if (currentListeningUserId == userId && transactionListener != null) return
        stopRealtimeListeners()
        currentListeningUserId = userId

        val db = firestore ?: return

        // 1. Live Transaction Listener (syncs status like APPROVED / REJECTED in real-time)
        try {
            transactionListener = db.collection("transactions")
                .whereEqualTo("userId", userId)
                .addSnapshotListener { snapshots, error ->
                    if (error != null || snapshots == null) return@addSnapshotListener
                    coroutineScope.launch {
                        for (doc in snapshots.documents) {
                            val id = doc.getString("id") ?: doc.id
                            val status = doc.getString("status") ?: "PENDING"
                            val title = doc.getString("title") ?: "Transaction"
                            val subtitle = doc.getString("subtitle") ?: ""
                            val type = doc.getString("type") ?: "TASK"
                            val amountRupees = doc.getDouble("amountRupees") ?: 0.0
                            val amountCoins = (doc.getLong("amountCoins") ?: 0L).toInt()
                            val isCredit = doc.getBoolean("isCredit") ?: true
                            val timestamp = doc.getLong("timestamp") ?: System.currentTimeMillis()
                            val referenceId = doc.getString("referenceId") ?: ""

                            val txn = TransactionEntity(
                                id = id,
                                userId = userId,
                                type = type,
                                title = title,
                                subtitle = subtitle,
                                amountRupees = amountRupees,
                                amountCoins = amountCoins,
                                isCredit = isCredit,
                                status = status,
                                timestamp = timestamp,
                                referenceId = referenceId
                            )
                            transactionDao.insertTransaction(txn)
                        }
                    }
                }
        } catch (e: Exception) {
            // Firestore not ready or offline
        }

        // 2. Live Wallet Listener (syncs wallet balance changes in real-time)
        try {
            walletListener = db.collection("wallets").document(userId)
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null || !snapshot.exists()) return@addSnapshotListener
                    coroutineScope.launch {
                        val coins = (snapshot.getLong("balanceCoins") ?: 0L).toInt()
                        val rupees = coins / 100.0
                        val todayEarned = snapshot.getDouble("todayEarnedRupees") ?: 0.0
                        val totalEarned = snapshot.getDouble("totalEarnedRupees") ?: 0.0
                        val pending = snapshot.getDouble("pendingWithdrawalRupees") ?: 0.0
                        val withdrawn = snapshot.getDouble("totalWithdrawnRupees") ?: 0.0
                        val lastUpdated = snapshot.getString("lastUpdatedDate") ?: getTodayDateString()

                        val wallet = WalletEntity(
                            userId = userId,
                            balanceCoins = coins,
                            balanceRupees = rupees,
                            todayEarnedRupees = todayEarned,
                            totalEarnedRupees = totalEarned,
                            pendingWithdrawalRupees = pending,
                            totalWithdrawnRupees = withdrawn,
                            lastUpdatedDate = lastUpdated
                        )
                        walletDao.insertOrUpdateWallet(wallet)
                    }
                }
        } catch (e: Exception) {
            // Handle offline
        }

        // 3. Live Withdrawal Listener (syncs withdrawal status in real-time)
        try {
            withdrawalListener = db.collection("withdrawals")
                .whereEqualTo("userId", userId)
                .addSnapshotListener { snapshots, error ->
                    if (error != null || snapshots == null) return@addSnapshotListener
                    coroutineScope.launch {
                        for (doc in snapshots.documents) {
                            val id = doc.getString("id") ?: doc.id
                            val userName = doc.getString("userName") ?: ""
                            val amountRupees = doc.getDouble("amountRupees") ?: 0.0
                            val paymentMethod = doc.getString("paymentMethod") ?: "UPI"
                            val accountHolder = doc.getString("accountHolder") ?: ""
                            val upiOrAccount = doc.getString("upiOrAccount") ?: ""
                            val ifsc = doc.getString("ifsc") ?: ""
                            val status = doc.getString("status") ?: "PENDING"
                            val requestTimestamp = doc.getLong("requestTimestamp") ?: System.currentTimeMillis()
                            val processedTimestamp = doc.getLong("processedTimestamp")
                            val adminNote = doc.getString("adminNote") ?: ""

                            val withdrawal = WithdrawalEntity(
                                id = id,
                                userId = userId,
                                userName = userName,
                                amountRupees = amountRupees,
                                paymentMethod = paymentMethod,
                                accountHolder = accountHolder,
                                upiOrAccount = upiOrAccount,
                                ifsc = ifsc,
                                status = status,
                                requestTimestamp = requestTimestamp,
                                processedTimestamp = processedTimestamp,
                                adminNote = adminNote
                            )
                            withdrawalDao.insertWithdrawal(withdrawal)
                        }
                    }
                }
        } catch (e: Exception) {
            // Handle offline
        }

        // 4. Live Game Progress Listener (syncs game levels e.g. Arrow Escape in real-time)
        try {
            gameProgressListener = db.collection("users").document(userId)
                .collection("game_progress")
                .addSnapshotListener { snapshots, error ->
                    if (error != null || snapshots == null) return@addSnapshotListener
                    coroutineScope.launch {
                        for (doc in snapshots.documents) {
                            val gameId = doc.getString("gameId") ?: doc.id
                            val currentLevel = (doc.getLong("currentLevel") ?: 1L).toInt()
                            val highScore = (doc.getLong("highScore") ?: 0L).toInt()
                            val totalPlays = (doc.getLong("totalPlays") ?: 0L).toInt()
                            val lastPlayed = doc.getLong("lastPlayedTimestamp") ?: System.currentTimeMillis()

                            val existing = gameProgressDao.getGameProgressDirect(userId, gameId)
                            val progress = GameProgressEntity(
                                key = "${userId}_$gameId",
                                userId = userId,
                                gameId = gameId,
                                currentLevel = maxOf(existing?.currentLevel ?: 1, currentLevel),
                                highScore = maxOf(existing?.highScore ?: 0, highScore),
                                totalPlays = maxOf(existing?.totalPlays ?: 0, totalPlays),
                                lastPlayedTimestamp = lastPlayed
                            )
                            gameProgressDao.saveGameProgress(progress)
                        }
                    }
                }
        } catch (e: Exception) {
            // Handle offline
        }
    }

    fun stopRealtimeListeners() {
        try {
            transactionListener?.remove()
            transactionListener = null
            walletListener?.remove()
            walletListener = null
            withdrawalListener?.remove()
            withdrawalListener = null
            gameProgressListener?.remove()
            gameProgressListener = null
            currentListeningUserId = null
        } catch (e: Exception) {
            // Ignore cleanup failure
        }
    }

    fun logout() {
        stopRealtimeListeners()
        try {
            firebaseAuth?.signOut()
        } catch (e: Exception) {
            // Ignore signOut failure
        }
    }

    // ----------------------------------------------------
    // Secure Wallet & Earnings
    // ----------------------------------------------------
    fun getWallet(userId: String): Flow<WalletEntity?> = walletDao.getWalletByUserId(userId)
    fun getAllWallets(): Flow<List<WalletEntity>> = walletDao.getAllWallets()

    suspend fun creditReward(
        userId: String,
        coins: Int,
        rupees: Double,
        type: String,
        title: String,
        subtitle: String,
        refId: String = ""
    ): Result<TransactionEntity> {
        val currentWallet = walletDao.getWalletDirect(userId) ?: WalletEntity(userId = userId)

        // Calculate rupee equivalent strictly as (Coins / 100.0)
        val calculatedCoins = if (coins > 0) coins else (rupees * 100).toInt()
        val calculatedRupees = calculatedCoins / 100.0

        val newBalanceCoins = currentWallet.balanceCoins + calculatedCoins
        val newBalanceRupees = newBalanceCoins / 100.0

        val todayStr = getTodayDateString()
        val prevTodayEarned = if (currentWallet.lastUpdatedDate == todayStr) currentWallet.todayEarnedRupees else 0.0
        val updatedWallet = currentWallet.copy(
            balanceCoins = newBalanceCoins,
            balanceRupees = newBalanceRupees,
            todayEarnedRupees = prevTodayEarned + calculatedRupees,
            totalEarnedRupees = currentWallet.totalEarnedRupees + calculatedRupees,
            lastUpdatedDate = todayStr
        )
        walletDao.insertOrUpdateWallet(updatedWallet)
        syncWalletToFirestore(updatedWallet)

        val txn = TransactionEntity(
            id = "TXN_" + UUID.randomUUID().toString().substring(0, 8).uppercase(),
            userId = userId,
            type = type,
            title = title,
            subtitle = subtitle,
            amountRupees = calculatedRupees,
            amountCoins = calculatedCoins,
            isCredit = true,
            status = "COMPLETED",
            timestamp = System.currentTimeMillis(),
            referenceId = refId
        )
        transactionDao.insertTransaction(txn)
        syncTransactionToFirestore(txn)
        return Result.success(txn)
    }

    // ----------------------------------------------------
    // Tasks System
    // ----------------------------------------------------
    fun getActiveTasks(): Flow<List<TaskEntity>> = taskDao.getActiveTasks().map { list ->
        list.filter {
            it.id != "task_complete_level" &&
            it.id != "task_daily_challenge" &&
            !it.title.contains("Complete Game Level", true) &&
            !it.title.contains("Daily Challenge", true)
        }
    }
    fun getAllTasks(): Flow<List<TaskEntity>> = taskDao.getAllTasks().map { list ->
        list.filter {
            it.id != "task_complete_level" &&
            it.id != "task_daily_challenge" &&
            !it.title.contains("Complete Game Level", true) &&
            !it.title.contains("Daily Challenge", true)
        }
    }

    suspend fun claimTaskReward(userId: String, taskId: String): Result<String> {
        val task = taskDao.getTaskById(taskId) ?: return Result.failure(Exception("Task not found"))
        val today = getTodayDateString()

        if (!task.isRepeatable && task.isCompleted) {
            return Result.failure(Exception("Task already completed"))
        }
        if (task.isRepeatable && task.lastCompletedDate == today) {
            return Result.failure(Exception("Task already claimed today. Try again tomorrow!"))
        }

        // Credit the reward
        creditReward(
            userId = userId,
            coins = task.rewardCoins,
            rupees = task.rewardRupees,
            type = if (task.iconType == "ad") "AD" else if (task.iconType == "checkin") "CHECKIN" else "TASK",
            title = task.title,
            subtitle = task.description,
            refId = taskId
        )

        // Update task state
        val updatedTask = task.copy(
            isCompleted = true,
            lastCompletedDate = today,
            currentProgress = task.targetProgress
        )
        taskDao.updateTask(updatedTask)

        return Result.success("Reward +${task.rewardCoins} Coins claimed successfully!")
    }

    suspend fun saveOrUpdateTask(task: TaskEntity) {
        taskDao.insertTask(task)
    }

    suspend fun deleteTask(taskId: String) {
        taskDao.deleteTask(taskId)
    }

    // ----------------------------------------------------
    // Games Progress & Rewards
    // ----------------------------------------------------
    fun getGameProgress(userId: String, gameId: String): Flow<GameProgressEntity?> =
        gameProgressDao.getGameProgress(userId, gameId)

    fun getAllGamesProgress(userId: String): Flow<List<GameProgressEntity>> =
        gameProgressDao.getAllGamesProgress(userId)

    suspend fun completeGameLevel(
        userId: String,
        gameId: String,
        levelCompleted: Int,
        score: Int,
        watchAdRewardClaimed: Boolean,
        customRewardCoins: Int? = null
    ): Result<Int> {
        val key = "${userId}_$gameId"
        val existing = gameProgressDao.getGameProgressDirect(userId, gameId) ?: GameProgressEntity(
            key = key,
            userId = userId,
            gameId = gameId,
            currentLevel = levelCompleted,
            highScore = score,
            totalPlays = 1
        )

        val nextLevel = maxOf(existing.currentLevel, levelCompleted + 1)
        val newHighScore = maxOf(existing.highScore, score)
        val updated = existing.copy(
            currentLevel = nextLevel,
            highScore = newHighScore,
            totalPlays = existing.totalPlays + 1,
            lastPlayedTimestamp = System.currentTimeMillis()
        )
        gameProgressDao.saveGameProgress(updated)
        syncGameProgressToFirestore(updated)

        // Award reward if ad was watched
        if (watchAdRewardClaimed) {
            val config = appConfigDao.getAppConfigDirect() ?: AppConfigEntity()
            val rate = if (config.coinToRupeeRate > 0.0) config.coinToRupeeRate else 0.01
            val rewardCoins = customRewardCoins ?: when (gameId) {
                "arrow_escape", "tap_coin" -> (1..50).random()
                "color_match" -> config.colorMatchRewardCoins
                "catch_candy" -> config.catchCandyRewardCoins
                else -> (1..50).random()
            }
            val gameTitle = when (gameId) {
                "arrow_escape" -> "Arrow Escape"
                "tap_coin" -> "Tap Coin"
                "color_match" -> "Color Match"
                "catch_candy" -> "Catch Candy"
                else -> "Game"
            }
            creditReward(
                userId = userId,
                coins = rewardCoins,
                rupees = rewardCoins / 100.0,
                type = "GAME",
                title = "Game Reward",
                subtitle = "Level $levelCompleted Complete ($gameTitle)",
                refId = "$gameId#$levelCompleted"
            )
        }

        return Result.success(nextLevel)
    }

    // ----------------------------------------------------
    // Withdrawals & Validation
    // ----------------------------------------------------
    fun getWithdrawalsByUser(userId: String): Flow<List<WithdrawalEntity>> =
        withdrawalDao.getWithdrawalsByUser(userId)

    fun getAllWithdrawals(): Flow<List<WithdrawalEntity>> =
        withdrawalDao.getAllWithdrawals()

    suspend fun requestWithdrawal(
        userId: String,
        userName: String,
        amountRupees: Double,
        paymentMethod: String,
        accountHolder: String,
        upiOrAccount: String,
        ifsc: String = ""
    ): Result<WithdrawalEntity> {
        val config = appConfigDao.getAppConfigDirect() ?: AppConfigEntity()
        val wallet = walletDao.getWalletDirect(userId)
            ?: return Result.failure(Exception("Wallet not found"))
        val minRupees = if (config.minWithdrawalRupees > 0.0) config.minWithdrawalRupees else 50.0
        val requestedCoins = (amountRupees * 100).toInt()

        // Validations: require at least 5000 coins / ₹50 to submit a request
        if (amountRupees < minRupees || requestedCoins < 5000) {
            return Result.failure(Exception("Minimum withdrawal limit is ₹50.00 (5,000 Coins)"))
        }
        val currentCoins = wallet.balanceCoins
        val currentRupees = currentCoins / 100.0
        if (amountRupees > currentRupees || requestedCoins > currentCoins) {
            return Result.failure(Exception("Insufficient balance! Available: ₹${String.format(java.util.Locale.US, "%.2f", currentRupees)} ($currentCoins Coins)"))
        }
        if (upiOrAccount.isBlank()) {
            return Result.failure(Exception("Please enter valid payment details"))
        }
        if (paymentMethod == "UPI" && (!upiOrAccount.contains("@") || upiOrAccount.length < 5)) {
            return Result.failure(Exception("Invalid UPI ID format (e.g. yourname@upi)"))
        }
        if (paymentMethod == "BANK" && (ifsc.isBlank() || upiOrAccount.length < 8)) {
            return Result.failure(Exception("Please enter valid Bank Account number and IFSC code"))
        }

        // Deduct from available balance & move to pending withdrawal
        val remainingCoins = (wallet.balanceCoins - requestedCoins).coerceAtLeast(0)
        val remainingRupees = remainingCoins / 100.0
        val updatedWallet = wallet.copy(
            balanceRupees = remainingRupees,
            balanceCoins = remainingCoins,
            pendingWithdrawalRupees = wallet.pendingWithdrawalRupees + amountRupees
        )
        walletDao.insertOrUpdateWallet(updatedWallet)
        syncWalletToFirestore(updatedWallet)

        val withdrawalId = "WTH_" + UUID.randomUUID().toString().substring(0, 8).uppercase()
        val withdrawal = WithdrawalEntity(
            id = withdrawalId,
            userId = userId,
            userName = userName,
            amountRupees = amountRupees,
            paymentMethod = paymentMethod,
            accountHolder = accountHolder,
            upiOrAccount = upiOrAccount,
            ifsc = ifsc,
            status = "PENDING"
        )
        withdrawalDao.insertWithdrawal(withdrawal)
        syncWithdrawalToFirestore(withdrawal)

        val txn = TransactionEntity(
            id = "TXN_" + UUID.randomUUID().toString().substring(0, 8).uppercase(),
            userId = userId,
            type = "WITHDRAWAL",
            title = "Withdrawal Request",
            subtitle = "$paymentMethod: $upiOrAccount",
            amountRupees = amountRupees,
            amountCoins = requestedCoins,
            isCredit = false,
            status = "PENDING",
            referenceId = withdrawalId
        )
        transactionDao.insertTransaction(txn)
        syncTransactionToFirestore(txn)

        return Result.success(withdrawal)
    }

    suspend fun processWithdrawalAdmin(
        withdrawalId: String,
        newStatus: String, // "APPROVED", "REJECTED", "PAID"
        note: String
    ): Result<WithdrawalEntity> {
        val withdrawal = withdrawalDao.getWithdrawalById(withdrawalId)
            ?: return Result.failure(Exception("Withdrawal record not found"))

        val updated = withdrawal.copy(
            status = newStatus,
            processedTimestamp = System.currentTimeMillis(),
            adminNote = note
        )
        withdrawalDao.updateWithdrawal(updated)
        syncWithdrawalToFirestore(updated)

        val wallet = walletDao.getWalletDirect(withdrawal.userId)
        val config = appConfigDao.getAppConfigDirect() ?: AppConfigEntity()
        val rate = if (config.coinToRupeeRate > 0.0) config.coinToRupeeRate else 0.01

        if (wallet != null) {
            if (newStatus == "REJECTED") {
                // Refund pending balance back to available
                val restoredCoins = wallet.balanceCoins + (withdrawal.amountRupees * 100).toInt()
                val refundedWallet = wallet.copy(
                    balanceCoins = restoredCoins,
                    balanceRupees = restoredCoins / 100.0,
                    pendingWithdrawalRupees = (wallet.pendingWithdrawalRupees - withdrawal.amountRupees).coerceAtLeast(0.0)
                )
                walletDao.insertOrUpdateWallet(refundedWallet)
                syncWalletToFirestore(refundedWallet)
            } else if (newStatus == "PAID" || newStatus == "APPROVED") {
                val paidWallet = wallet.copy(
                    pendingWithdrawalRupees = (wallet.pendingWithdrawalRupees - withdrawal.amountRupees).coerceAtLeast(0.0),
                    totalWithdrawnRupees = wallet.totalWithdrawnRupees + withdrawal.amountRupees
                )
                walletDao.insertOrUpdateWallet(paidWallet)
                syncWalletToFirestore(paidWallet)
            }
        }

        // Record status change transaction log
        val txn = TransactionEntity(
            id = "TXN_" + UUID.randomUUID().toString().substring(0, 8).uppercase(),
            userId = withdrawal.userId,
            type = "WITHDRAWAL",
            title = "Withdrawal $newStatus",
            subtitle = "Amount: ₹${withdrawal.amountRupees} ($note)",
            amountRupees = withdrawal.amountRupees,
            amountCoins = (withdrawal.amountRupees * 100).toInt(),
            isCredit = (newStatus == "REJECTED"),
            status = newStatus,
            referenceId = withdrawalId
        )
        transactionDao.insertTransaction(txn)
        syncTransactionToFirestore(txn)

        return Result.success(updated)
    }

    // ----------------------------------------------------
    // Transactions
    // ----------------------------------------------------
    fun getTransactions(userId: String): Flow<List<TransactionEntity>> =
        transactionDao.getTransactionsByUser(userId)

    fun getTransactionsByType(userId: String, type: String): Flow<List<TransactionEntity>> =
        transactionDao.getTransactionsByType(userId, type)

    fun getAllTransactions(): Flow<List<TransactionEntity>> =
        transactionDao.getAllTransactions()

    // ----------------------------------------------------
    // App Config & Settings (Admin)
    // ----------------------------------------------------
    fun getAppConfig(): Flow<AppConfigEntity?> = appConfigDao.getAppConfig()

    suspend fun updateAppConfig(config: AppConfigEntity) {
        appConfigDao.saveAppConfig(config)
    }

    // ----------------------------------------------------
    // Notifications
    // ----------------------------------------------------
    fun getNotifications(userId: String): Flow<List<NotificationEntity>> =
        notificationDao.getNotificationsByUser(userId)

    fun getUnreadCount(userId: String): Flow<Int> =
        notificationDao.getUnreadCount(userId)

    suspend fun markNotificationsAsRead(userId: String) {
        notificationDao.markAllAsRead(userId)
    }

    // ----------------------------------------------------
    // Cloud Firestore Sync Helpers
    // ----------------------------------------------------
    private fun syncUserToFirestore(user: UserEntity) {
        try {
            val db = firestore ?: return
            val userData = hashMapOf(
                "id" to user.id,
                "name" to user.name,
                "email" to user.email,
                "phone" to user.phone,
                "referralCode" to user.referralCode,
                "referredBy" to (user.referredBy ?: ""),
                "isAdmin" to user.isAdmin,
                "passwordHash" to user.passwordHash,
                "createdAt" to user.createdAt
            )
            db.collection("users").document(user.id)
                .set(userData, SetOptions.merge())
        } catch (e: Exception) {
            // Silently fallback if offline
        }
    }

    private fun syncWalletToFirestore(wallet: WalletEntity) {
        try {
            val db = firestore ?: return
            val walletData = hashMapOf(
                "userId" to wallet.userId,
                "balanceCoins" to wallet.balanceCoins,
                "balanceRupees" to wallet.balanceRupees,
                "todayEarnedRupees" to wallet.todayEarnedRupees,
                "totalEarnedRupees" to wallet.totalEarnedRupees,
                "pendingWithdrawalRupees" to wallet.pendingWithdrawalRupees,
                "totalWithdrawnRupees" to wallet.totalWithdrawnRupees,
                "lastUpdatedDate" to wallet.lastUpdatedDate,
                "updatedAt" to System.currentTimeMillis()
            )
            db.collection("wallets").document(wallet.userId)
                .set(walletData, SetOptions.merge())
            db.collection("users").document(wallet.userId)
                .set(mapOf("wallet" to walletData, "lastActive" to System.currentTimeMillis()), SetOptions.merge())
        } catch (e: Exception) {
            // Silently fallback if offline
        }
    }

    private fun syncWithdrawalToFirestore(withdrawal: WithdrawalEntity) {
        try {
            val db = firestore ?: return
            val withdrawalData = hashMapOf(
                "id" to withdrawal.id,
                "userId" to withdrawal.userId,
                "userName" to withdrawal.userName,
                "amountRupees" to withdrawal.amountRupees,
                "paymentMethod" to withdrawal.paymentMethod,
                "accountHolder" to withdrawal.accountHolder,
                "upiOrAccount" to withdrawal.upiOrAccount,
                "ifsc" to withdrawal.ifsc,
                "status" to withdrawal.status,
                "requestTimestamp" to withdrawal.requestTimestamp,
                "processedTimestamp" to withdrawal.processedTimestamp,
                "adminNote" to withdrawal.adminNote
            )
            db.collection("withdrawals").document(withdrawal.id)
                .set(withdrawalData, SetOptions.merge())
            db.collection("users").document(withdrawal.userId)
                .collection("withdrawals").document(withdrawal.id)
                .set(withdrawalData, SetOptions.merge())
        } catch (e: Exception) {
            // Silently fallback if offline
        }
    }

    private fun syncTransactionToFirestore(txn: TransactionEntity) {
        try {
            val db = firestore ?: return
            val txnData = hashMapOf(
                "id" to txn.id,
                "userId" to txn.userId,
                "type" to txn.type,
                "title" to txn.title,
                "subtitle" to txn.subtitle,
                "amountRupees" to txn.amountRupees,
                "amountCoins" to txn.amountCoins,
                "isCredit" to txn.isCredit,
                "status" to txn.status,
                "timestamp" to txn.timestamp,
                "referenceId" to txn.referenceId
            )
            db.collection("transactions").document(txn.id)
                .set(txnData, SetOptions.merge())
            db.collection("users").document(txn.userId)
                .collection("transactions").document(txn.id)
                .set(txnData, SetOptions.merge())
        } catch (e: Exception) {
            // Silently fallback if offline
        }
    }

    private fun syncGameProgressToFirestore(progress: GameProgressEntity) {
        try {
            val db = firestore ?: return
            val progressData = hashMapOf(
                "userId" to progress.userId,
                "gameId" to progress.gameId,
                "currentLevel" to progress.currentLevel,
                "highScore" to progress.highScore,
                "totalPlays" to progress.totalPlays,
                "lastPlayedTimestamp" to progress.lastPlayedTimestamp
            )
            db.collection("users").document(progress.userId)
                .collection("game_progress").document(progress.gameId)
                .set(progressData, SetOptions.merge())
            db.collection("game_progress").document(progress.key)
                .set(progressData, SetOptions.merge())
        } catch (e: Exception) {
            // Silently fallback if offline
        }
    }

    private fun getTodayDateString(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return sdf.format(Date())
    }
}
