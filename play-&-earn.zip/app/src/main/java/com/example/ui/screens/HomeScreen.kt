package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.ActiveScreen
import com.example.ui.viewmodel.UserUiState

@Composable
fun HomeScreen(
    uiState: UserUiState,
    onWithdrawClick: () -> Unit,
    onPlayGamesClick: () -> Unit,
    onLaunchGame: (String) -> Unit = {},
    onTaskActionClick: (String, String) -> Unit,
    onNotificationClick: () -> Unit,
    onProfileClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val wallet = uiState.wallet
    val user = uiState.currentUser
    val dailyTasks = remember(uiState.tasks) {
        val filtered = uiState.tasks.filter { task ->
            task.id != "task_complete_level" &&
            task.id != "task_daily_challenge" &&
            !task.title.contains("Complete Game Level", ignoreCase = true) &&
            !task.title.contains("Daily Challenge", ignoreCase = true)
        }
        val orderMap = mapOf(
            "task_daily_checkin" to 1,
            "task_watch_ad" to 2,
            "task_play_game" to 3
        )
        filtered.sortedBy { orderMap[it.id] ?: 99 }
    }

    val progressList = uiState.gamesProgress
    val arrowEscapeLevel = progressList.find { it.gameId == "arrow_escape" }?.currentLevel ?: 1
    val tapCoinLevel = progressList.find { it.gameId == "tap_coin" }?.currentLevel ?: 25

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ScreenBackground)
            .testTag("home_screen"),
        contentPadding = PaddingValues(bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Top Section: Gradient Bento Header Banner
        item {
            PlayAndEarnTopBar(
                userName = user?.name ?: "Suman Kumar",
                unreadNotifCount = uiState.unreadNotifCount,
                onNotificationClick = onNotificationClick,
                onProfileClick = onProfileClick
            )
        }

        // Bento Wallet Card Section overlapping banner
        item {
            val homeCoins = wallet?.balanceCoins ?: 1255
            val homeRupees = homeCoins / 100.0
            Box(
                modifier = Modifier
                    .padding(horizontal = 20.dp)
                    .offset(y = (-20).dp)
            ) {
                WalletCard(
                    balanceRupees = homeRupees,
                    balanceCoins = homeCoins,
                    todayEarn = uiState.todayEarnedRupees,
                    totalEarn = uiState.totalEarnedRupees,
                    onWithdrawClick = onWithdrawClick,
                    onPaymentMethodClick = onWithdrawClick
                )
            }
        }

        // DAILY TASKS Bento Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .offset(y = (-12).dp)
                    .padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "DAILY TASKS",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    color = TextDark,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = "Earn Every Day",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = BrandIndigo
                )
            }
        }

        // Bento Task Cards (Daily Check-in, Watch Ad, Play Game)
        items(dailyTasks) { task ->
            Box(
                modifier = Modifier
                    .padding(horizontal = 20.dp)
                    .offset(y = (-12).dp)
            ) {
                TaskItemCard(
                    task = task,
                    onActionClick = { onTaskActionClick(task.id, task.actionRoute) }
                )
            }
        }

        // GAMES Bento Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .offset(y = (-4).dp)
                    .padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "GAMES",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    color = TextDark,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = "Play & Win Coins",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = BrandIndigo
                )
            }
        }

        // Side-by-side Games: Tap Tap & Arrow Escape
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .offset(y = (-2).dp)
                    .padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                SideBySideGameCard(
                    gameId = "tap_coin",
                    title = "Tap Tap",
                    subtitle = "Fast Finger Tap",
                    level = tapCoinLevel,
                    iconRes = R.drawable.ic_tap_coin,
                    accentColor = RewardGold,
                    onPlayClick = { onLaunchGame("tap_coin") },
                    modifier = Modifier.weight(1f)
                )

                SideBySideGameCard(
                    gameId = "arrow_escape",
                    title = "Arrow Escape",
                    subtitle = "Arrow Maze Puzzle",
                    level = arrowEscapeLevel,
                    iconRes = R.drawable.ic_arrow_escape,
                    accentColor = Color(0xFF6366F1),
                    onPlayClick = { onLaunchGame("arrow_escape") },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Bento Promotional Game Banner: PLAY GAMES EARN BIG REWARDS
        item {
            Box(
                modifier = Modifier
                    .padding(horizontal = 20.dp)
                    .offset(y = (-2).dp)
            ) {
                GamePromoBanner(
                    onPlayClick = onPlayGamesClick
                )
            }
        }
    }
}

