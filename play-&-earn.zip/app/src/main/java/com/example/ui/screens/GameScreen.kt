package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.GameLauncherCard
import com.example.ui.components.PlayAndEarnTopBar
import com.example.ui.components.SideBySideGameCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.UserUiState

@Composable
fun GameScreen(
    uiState: UserUiState,
    onLaunchGame: (String) -> Unit,
    onNotificationClick: () -> Unit,
    onProfileClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val progressList = uiState.gamesProgress
    val arrowEscapeLevel = progressList.find { it.gameId == "arrow_escape" }?.currentLevel ?: 1
    val tapCoinLevel = progressList.find { it.gameId == "tap_coin" }?.currentLevel ?: 25
    val colorMatchLevel = progressList.find { it.gameId == "color_match" }?.currentLevel ?: 12
    val catchCandyLevel = progressList.find { it.gameId == "catch_candy" }?.currentLevel ?: 8

    val config = uiState.appConfig

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ScreenBackground)
            .testTag("game_screen"),
        contentPadding = PaddingValues(bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            PlayAndEarnTopBar(
                userName = uiState.currentUser?.name ?: "Suman Kumar",
                unreadNotifCount = uiState.unreadNotifCount,
                onNotificationClick = onNotificationClick,
                onProfileClick = onProfileClick
            )
        }

        // Header Title & Subtitle
        item {
            Column(modifier = Modifier.padding(horizontal = 20.dp)) {
                Text(
                    text = "Games",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = TextPrimary
                )
                Text(
                    text = "Play Games & Earn Rewards",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = TextSecondary
                )
            }
        }

        // FEATURED GAMES SIDE-BY-SIDE: "Tap Tap" & "Arrow Escape"
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Game a: Tap Tap
                SideBySideGameCard(
                    gameId = "tap_coin",
                    title = "Tap Tap",
                    subtitle = "Fast Finger Tap",
                    level = tapCoinLevel,
                    iconRes = R.drawable.ic_tap_coin,
                    accentColor = RewardGold,
                    onPlayClick = { onLaunchGame("tap_coin") },
                    modifier = Modifier.weight(1f)
                )

                // Game b: Arrow Escape
                SideBySideGameCard(
                    gameId = "arrow_escape",
                    title = "Arrow Escape",
                    subtitle = "Arrow Maze Puzzle",
                    level = arrowEscapeLevel,
                    iconRes = R.drawable.ic_arrow_escape,
                    accentColor = Color(0xFF6366F1),
                    onPlayClick = { onLaunchGame("arrow_escape") },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // All Games Section Header
        item {
            Text(
                text = "All Games",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
            )
        }

        // GAME 1: Tap Tap
        item {
            Box(modifier = Modifier.padding(horizontal = 20.dp)) {
                GameLauncherCard(
                    gameId = "tap_coin",
                    title = "Tap Tap",
                    description = "Unlimited Levels • Fast Finger Tap",
                    level = tapCoinLevel,
                    iconRes = R.drawable.ic_tap_coin,
                    accentColor = RewardGold,
                    onPlayClick = { onLaunchGame("tap_coin") }
                )
            }
        }

        // GAME 2: Arrow Escape
        item {
            Box(modifier = Modifier.padding(horizontal = 20.dp)) {
                GameLauncherCard(
                    gameId = "arrow_escape",
                    title = "Arrow Escape",
                    description = "Solve Arrow Mazes & Win Coins",
                    level = arrowEscapeLevel,
                    iconRes = R.drawable.ic_arrow_escape,
                    accentColor = Color(0xFF6366F1),
                    onPlayClick = { onLaunchGame("arrow_escape") }
                )
            }
        }

        // GAME 3: Color Match
        if (config.isColorMatchEnabled) {
            item {
                Box(modifier = Modifier.padding(horizontal = 20.dp)) {
                    GameLauncherCard(
                        gameId = "color_match",
                        title = "Color Match",
                        description = "Unlimited Levels • Reflex & Speed",
                        level = colorMatchLevel,
                        iconRes = R.drawable.ic_color_match,
                        accentColor = Color(0xFF10B981),
                        onPlayClick = { onLaunchGame("color_match") }
                    )
                }
            }
        }

        // GAME 4: Catch Candy
        if (config.isCatchCandyEnabled) {
            item {
                Box(modifier = Modifier.padding(horizontal = 20.dp)) {
                    GameLauncherCard(
                        gameId = "catch_candy",
                        title = "Catch Candy",
                        description = "Unlimited Levels • Arcade Catch",
                        level = catchCandyLevel,
                        iconRes = R.drawable.ic_catch_candy,
                        accentColor = Color(0xFFFF4757),
                        onPlayClick = { onLaunchGame("catch_candy") }
                    )
                }
            }
        }
    }
}
