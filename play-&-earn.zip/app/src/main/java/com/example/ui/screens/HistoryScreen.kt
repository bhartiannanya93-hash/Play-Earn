package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.TransactionEntity
import com.example.ui.components.EmptyStateView
import com.example.ui.components.PlayAndEarnTopBar
import com.example.ui.theme.*
import com.example.ui.viewmodel.UserUiState
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun HistoryScreen(
    uiState: UserUiState,
    onNotificationClick: () -> Unit,
    onProfileClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf("ALL") }
    val tabs = listOf("ALL", "EARNING", "WITHDRAWAL", "TASK")

    val filteredList = remember(uiState.transactions, selectedTab) {
        when (selectedTab) {
            "ALL" -> uiState.transactions
            "EARNING" -> uiState.transactions.filter { it.isCredit }
            "WITHDRAWAL" -> uiState.transactions.filter { !it.isCredit }
            "TASK" -> uiState.transactions.filter { it.type == "TASK" || it.type == "CHECKIN" || it.type == "AD" }
            else -> uiState.transactions
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ScreenBackground)
            .testTag("history_screen"),
        contentPadding = PaddingValues(bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            PlayAndEarnTopBar(
                userName = uiState.currentUser?.name ?: "Suman Kumar",
                unreadNotifCount = uiState.unreadNotifCount,
                onNotificationClick = onNotificationClick,
                onProfileClick = onProfileClick
            )
        }

        // Header Title
        item {
            Column(modifier = Modifier.padding(horizontal = 20.dp)) {
                Text(
                    text = "Transaction History",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = TextPrimary
                )
                Text(
                    text = "All your earnings, game rewards and withdrawals",
                    fontSize = 13.sp,
                    color = TextSecondary
                )
            }
        }

        // Filter Tabs
        item {
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(tabs) { tab ->
                    val isSelected = selectedTab == tab
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedTab = tab },
                        label = {
                            Text(
                                text = if (tab == "ALL") "All History" else tab.lowercase().replaceFirstChar { it.uppercase() },
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = BrandPurplePrimary,
                            selectedLabelColor = Color.White,
                            containerColor = Color.White,
                            labelColor = TextSecondary
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            }
        }

        // Transactions List
        if (filteredList.isEmpty()) {
            item {
                EmptyStateView(
                    title = "No Transactions Found",
                    message = "Play games or complete tasks to see your transactions recorded here!",
                    iconRes = R.drawable.ic_coin_gold
                )
            }
        } else {
            items(filteredList) { txn ->
                Box(modifier = Modifier.padding(horizontal = 20.dp)) {
                    TransactionCard(txn)
                }
            }
        }
    }
}

@Composable
fun TransactionCard(txn: TransactionEntity) {
    val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
    val dateStr = sdf.format(Date(txn.timestamp))

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(3.dp, RoundedCornerShape(18.dp)),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                // Type Icon Box
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            if (txn.isCredit) RewardGreenLight else Color(0xFFFFEAEA)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        painter = painterResource(
                            id = when (txn.type) {
                                "GAME" -> R.drawable.ic_gamepad
                                "AD" -> R.drawable.ic_video_ad
                                "CHECKIN" -> R.drawable.ic_daily_checkin
                                "REFERRAL" -> R.drawable.ic_referral_gift
                                "WITHDRAWAL" -> R.drawable.ic_wallet_card
                                else -> R.drawable.ic_coin_gold
                            }
                        ),
                        contentDescription = null,
                        tint = Color.Unspecified,
                        modifier = Modifier.size(26.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = txn.title,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = txn.subtitle,
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = dateStr,
                        fontSize = 10.sp,
                        color = TextMuted
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Column(horizontalAlignment = Alignment.End) {
                val displayRupees = if (txn.amountCoins > 0) {
                    txn.amountCoins / 100.0
                } else {
                    txn.amountRupees
                }
                Text(
                    text = (if (txn.isCredit) "+" else "-") + String.format(java.util.Locale.US, "₹%.2f", displayRupees),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = if (txn.isCredit) RewardGreenDark else RewardOrange
                )
                if (txn.amountCoins > 0) {
                    Text(
                        text = (if (txn.isCredit) "+" else "-") + "${txn.amountCoins} Coins",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextSecondary
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(
                            when (txn.status) {
                                "COMPLETED", "APPROVED", "PAID" -> RewardGreenLight
                                "PENDING" -> RewardGoldLight
                                else -> Color(0xFFFFEAEA)
                            }
                        )
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = txn.status,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (txn.status) {
                            "COMPLETED", "APPROVED", "PAID" -> RewardGreenDark
                            "PENDING" -> Color(0xFFB45309)
                            else -> RewardRed
                        }
                    )
                }
            }
        }
    }
}
