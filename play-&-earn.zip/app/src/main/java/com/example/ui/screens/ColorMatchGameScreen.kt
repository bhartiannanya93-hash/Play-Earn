package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.*
import kotlinx.coroutines.delay

data class ColorOption(val id: Int, val name: String, val color: Color)

val ALL_GAME_COLORS = listOf(
    ColorOption(1, "Vibrant Cyan", Color(0xFF00D2D3)),
    ColorOption(2, "Sunset Orange", Color(0xFFFF9F43)),
    ColorOption(3, "Emerald Green", Color(0xFF10B981)),
    ColorOption(4, "Neon Pink", Color(0xFFFF6B6B)),
    ColorOption(5, "Royal Purple", Color(0xFF5F27CD)),
    ColorOption(6, "Bright Yellow", Color(0xFFFECA57)),
    ColorOption(7, "Electric Blue", Color(0xFF54A0FF)),
    ColorOption(8, "Lime Splash", Color(0xFF1DD1A1))
)

@Composable
fun ColorMatchGameScreen(
    currentLevel: Int,
    coinBalance: Int,
    rewardCoinsPerLevel: Int = 5,
    onBackClick: () -> Unit,
    onWatchAdAndClaim: (level: Int, score: Int, onAdRewardDone: () -> Unit) -> Unit,
    modifier: Modifier = Modifier
) {
    var activeLevel by remember(currentLevel) { mutableStateOf(currentLevel) }
    val targetScore = remember(activeLevel) { 5 + (activeLevel - 1) * 2 }
    var score by remember(activeLevel) { mutableStateOf(0) }
    var isLevelComplete by remember { mutableStateOf(false) }
    var isRewardClaimed by remember { mutableStateOf(false) }

    // Colors pool for current round
    var currentChoices by remember { mutableStateOf(ALL_GAME_COLORS.shuffled().take(4)) }
    var targetColor by remember { mutableStateOf(currentChoices.random()) }

    fun nextRound() {
        val newPool = ALL_GAME_COLORS.shuffled().take(4)
        currentChoices = newPool
        targetColor = newPool.random()
    }

    fun onChoiceSelected(chosen: ColorOption) {
        if (isLevelComplete) return

        if (chosen.id == targetColor.id) {
            score += 1
            if (score >= targetScore) {
                isLevelComplete = true
            } else {
                nextRound()
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF0F2027),
                        Color(0xFF203A43),
                        Color(0xFF2C5364)
                    )
                )
            )
            .testTag("color_match_game_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.15f))
                        .testTag("game_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }

                Text(
                    text = "COLOR MATCH",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    letterSpacing = 1.sp
                )

                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color.White.copy(alpha = 0.15f))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.ic_coin_gold),
                        contentDescription = null,
                        tint = Color.Unspecified,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "$coinBalance",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = RewardGoldLight
                    )
                }
            }

            // Game Play Area
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF10B981))
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "Level $activeLevel",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Match the Target Color below!",
                    fontSize = 14.sp,
                    color = Color.White.copy(alpha = 0.85f)
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Target Color Preview Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth(0.75f)
                        .shadow(12.dp, RoundedCornerShape(20.dp)),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = targetColor.color)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "TARGET COLOR",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.Black.copy(alpha = 0.7f),
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = targetColor.name,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Color choices 2x2 grid
                Column(
                    modifier = Modifier.fillMaxWidth(0.85f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        currentChoices.take(2).forEach { option ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(70.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(option.color)
                                    .clickable { onChoiceSelected(option) }
                                    .testTag("color_choice_${option.id}"),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = option.name,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        currentChoices.drop(2).take(2).forEach { option ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(70.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(option.color)
                                    .clickable { onChoiceSelected(option) }
                                    .testTag("color_choice_${option.id}"),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = option.name,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Score bar
                LinearProgressIndicator(
                    progress = { (score.toFloat() / targetScore.toFloat()).coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth(0.85f)
                        .height(12.dp)
                        .clip(RoundedCornerShape(6.dp)),
                    color = Color(0xFF10B981),
                    trackColor = Color.White.copy(alpha = 0.2f)
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "$score / $targetScore Matches",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            // Bottom Level Complete Box
            AnimatedVisibility(
                visible = isLevelComplete,
                enter = fadeIn() + slideInVertically { it / 2 }
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(16.dp, RoundedCornerShape(24.dp)),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "🎉 LEVEL $activeLevel COMPLETE!",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "Reward: +$rewardCoinsPerLevel Coins",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = RewardGoldLight
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        if (!isRewardClaimed) {
                            Button(
                                onClick = {
                                    onWatchAdAndClaim(activeLevel, score) {
                                        isRewardClaimed = true
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = RewardGreen,
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("watch_ad_claim_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = null
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "WATCH AD & CLAIM REWARD",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        } else {
                            Button(
                                onClick = {
                                    activeLevel += 1
                                    score = 0
                                    isLevelComplete = false
                                    isRewardClaimed = false
                                    nextRound()
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF10B981),
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("next_level_button")
                            ) {
                                Text(
                                    text = "Next Level (Level ${activeLevel + 1}) →",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
