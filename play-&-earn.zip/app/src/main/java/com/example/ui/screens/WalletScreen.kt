package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.WithdrawalEntity
import com.example.ui.components.PlayAndEarnTopBar
import com.example.ui.components.WalletCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.UserUiState
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun WalletScreen(
    uiState: UserUiState,
    onWithdrawClick: () -> Unit,
    onNotificationClick: () -> Unit,
    onProfileClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val wallet = uiState.wallet
    val withdrawals = uiState.withdrawals
    var showPaymentMethodDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ScreenBackground)
            .testTag("wallet_screen"),
        contentPadding = PaddingValues(bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            PlayAndEarnTopBar(
                userName = uiState.currentUser?.name ?: "Suman Kumar",
                unreadNotifCount = uiState.unreadNotifCount,
                onNotificationClick = onNotificationClick,
                onProfileClick = onProfileClick
            )
        }

        // Wallet Balance Card
        item {
            val walletCoins = wallet?.balanceCoins ?: 1255
            val walletRupees = walletCoins / 100.0
            Box(
                modifier = Modifier
                    .padding(horizontal = 20.dp)
                    .offset(y = (-20).dp)
            ) {
                WalletCard(
                    balanceRupees = walletRupees,
                    balanceCoins = walletCoins,
                    todayEarn = uiState.todayEarnedRupees,
                    totalEarn = uiState.totalEarnedRupees,
                    onWithdrawClick = onWithdrawClick,
                    onPaymentMethodClick = onWithdrawClick
                )
            }
        }

        // Section 1: Payment Method Card (Bento Box)
        item {
            Box(
                modifier = Modifier
                    .padding(horizontal = 20.dp)
                    .offset(y = (-14).dp)
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(8.dp, RoundedCornerShape(22.dp), spotColor = Color(0x0F0F172A)),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = BentoBoxBg),
                    border = BorderStroke(1.dp, CardBorder)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(BrandPurpleLight),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        painter = painterResource(id = R.drawable.ic_wallet_card),
                                        contentDescription = null,
                                        tint = Color.Unspecified,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "Payment Method",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TextDark
                                    )
                                    Text(
                                        text = "UPI / Direct Bank Transfer",
                                        fontSize = 12.sp,
                                        color = TextMuted
                                    )
                                }
                            }

                            Button(
                                onClick = onWithdrawClick,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = BrandPurpleLight,
                                    contentColor = BrandIndigo
                                ),
                                shape = RoundedCornerShape(12.dp),
                                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                            ) {
                                Text("Manage", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Section 2: Earning Breakdown Report (Bento Box)
        item {
            Box(
                modifier = Modifier
                    .padding(horizontal = 20.dp)
                    .offset(y = (-10).dp)
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(8.dp, RoundedCornerShape(22.dp), spotColor = Color(0x0F0F172A)),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = BentoBoxBg),
                    border = BorderStroke(1.dp, CardBorder)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "EARNING REPORT",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            color = TextDark,
                            letterSpacing = 0.5.sp
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Stats Grid (3 Bento Cells)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            EarningStatPill(
                                title = "Games",
                                amount = "₹280.00",
                                icon = R.drawable.ic_gamepad,
                                color = BrandIndigo,
                                modifier = Modifier.weight(1f)
                            )
                            EarningStatPill(
                                title = "Tasks & Ads",
                                amount = "₹120.00",
                                icon = R.drawable.ic_video_ad,
                                color = RewardGreen,
                                modifier = Modifier.weight(1f)
                            )
                            EarningStatPill(
                                title = "Referral",
                                amount = "₹50.00",
                                icon = R.drawable.ic_referral_gift,
                                color = RewardOrange,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        // Section 3: Recent Withdrawal Requests Header
        item {
            Column(
                modifier = Modifier
                    .padding(horizontal = 20.dp)
                    .offset(y = (-6).dp)
            ) {
                Text(
                    text = "WITHDRAWAL REQUESTS",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    color = TextDark,
                    letterSpacing = 0.5.sp
                )
            }
        }

        if (withdrawals.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                        .offset(y = (-6).dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color.White)
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No withdrawal requests yet.\nPlay games to reach the minimum ₹50.00 (5,000 Coins)!",
                        fontSize = 13.sp,
                        color = TextMuted,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        } else {
            items(withdrawals) { item ->
                Box(
                    modifier = Modifier
                        .padding(horizontal = 20.dp)
                        .offset(y = (-6).dp)
                ) {
                    WithdrawalHistoryItemCard(item)
                }
            }
        }
    }
}

@Composable
fun EarningStatPill(
    title: String,
    amount: String,
    icon: Int,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = Color(0xFFF8FAFC),
        border = BorderStroke(1.dp, CardBorder)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                painter = painterResource(id = icon),
                contentDescription = null,
                tint = Color.Unspecified,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = title, fontSize = 11.sp, color = TextMuted, fontWeight = FontWeight.Medium)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = amount, fontSize = 13.sp, fontWeight = FontWeight.Black, color = TextDark)
        }
    }
}

@Composable
fun WithdrawalHistoryItemCard(item: WithdrawalEntity) {
    val sdf = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
    val dateStr = sdf.format(Date(item.requestTimestamp))

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(6.dp, RoundedCornerShape(20.dp), spotColor = Color(0x0A0F172A)),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = BentoBoxBg),
        border = BorderStroke(1.dp, CardBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            if (item.paymentMethod == "UPI") Color(0xFFEDE9FE) else Color(0xFFE0F2FE)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        painter = painterResource(
                            id = if (item.paymentMethod == "UPI") R.drawable.ic_upi_payment else R.drawable.ic_bank_payment
                        ),
                        contentDescription = null,
                        tint = Color.Unspecified,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "Withdrawal (${item.paymentMethod})",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextDark
                    )
                    Text(
                        text = item.upiOrAccount,
                        fontSize = 12.sp,
                        color = TextMuted
                    )
                    Text(
                        text = dateStr,
                        fontSize = 10.sp,
                        color = TextMuted
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = String.format(java.util.Locale.US, "-₹%.2f", item.amountRupees),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = RewardCoral
                )

                Spacer(modifier = Modifier.height(4.dp))

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(
                            when (item.status) {
                                "APPROVED", "PAID" -> RewardGreenLight
                                "PENDING" -> RewardGoldLight
                                else -> Color(0xFFFFEAEA)
                            }
                        )
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = item.status,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (item.status) {
                            "APPROVED", "PAID" -> RewardGreenDark
                            "PENDING" -> Color(0xFFB45309)
                            else -> RewardRed
                        }
                    )
                }
            }
        }
    }
}

