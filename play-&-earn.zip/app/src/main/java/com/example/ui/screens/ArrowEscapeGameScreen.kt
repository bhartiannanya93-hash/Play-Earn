package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.R
import com.example.ui.components.RewardedAdDialog
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

enum class ArrowDirection(val rotationDeg: Float) {
    UP(0f),
    RIGHT(90f),
    DOWN(180f),
    LEFT(270f)
}

data class ArrowTile(
    val id: String,
    val row: Int,
    val col: Int,
    val direction: ArrowDirection,
    val colorIndex: Int = 0
)

/**
 * Checks if an arrow's exit trajectory is blocked by any active arrow on the board.
 */
fun isArrowBlocked(tile: ArrowTile, activeTiles: List<ArrowTile>): Boolean {
    return when (tile.direction) {
        ArrowDirection.UP -> activeTiles.any { it.id != tile.id && it.col == tile.col && it.row < tile.row }
        ArrowDirection.DOWN -> activeTiles.any { it.id != tile.id && it.col == tile.col && it.row > tile.row }
        ArrowDirection.LEFT -> activeTiles.any { it.id != tile.id && it.row == tile.row && it.col < tile.col }
        ArrowDirection.RIGHT -> activeTiles.any { it.id != tile.id && it.row == tile.row && it.col > tile.col }
    }
}

/**
 * Automated check: immediately invalidates if adjacent arrows directly face each other:
 * e.g., '->' facing '<-' horizontally, or 'v' facing '^' vertically.
 */
fun hasDirectlyFacingAdjacentArrows(tiles: List<ArrowTile>): Boolean {
    val map = tiles.associateBy { it.row to it.col }
    for (tile in tiles) {
        // Horizontal: '->' facing '<-'
        if (tile.direction == ArrowDirection.RIGHT) {
            val rightNeighbor = map[tile.row to (tile.col + 1)]
            if (rightNeighbor != null && rightNeighbor.direction == ArrowDirection.LEFT) {
                return true
            }
        }
        // Vertical: 'v' facing '^'
        if (tile.direction == ArrowDirection.DOWN) {
            val bottomNeighbor = map[(tile.row + 1) to tile.col]
            if (bottomNeighbor != null && bottomNeighbor.direction == ArrowDirection.UP) {
                return true
            }
        }
    }
    return false
}

/**
 * Checks for any head-on collision in the same row or column with unobstructed line of sight.
 */
fun hasHeadOnCollisions(tiles: List<ArrowTile>): Boolean {
    val rowGroups = tiles.groupBy { it.row }
    for ((_, rowTiles) in rowGroups) {
        val sorted = rowTiles.sortedBy { it.col }
        for (i in 0 until sorted.size - 1) {
            if (sorted[i].direction == ArrowDirection.RIGHT && sorted[i + 1].direction == ArrowDirection.LEFT) {
                return true
            }
        }
    }
    val colGroups = tiles.groupBy { it.col }
    for ((_, colTiles) in colGroups) {
        val sorted = colTiles.sortedBy { it.row }
        for (i in 0 until sorted.size - 1) {
            if (colTiles[i].direction == ArrowDirection.DOWN && colTiles[i + 1].direction == ArrowDirection.UP) {
                return true
            }
        }
    }
    return false
}

/**
 * Forward-simulation solver: verifies that the board is 100% winnable with zero deadlocks.
 */
fun isBoard100PercentSolvable(gridSize: Int, tiles: List<ArrowTile>): Boolean {
    if (tiles.isEmpty()) return true
    val remaining = tiles.toMutableList()
    var progress = true
    while (progress && remaining.isNotEmpty()) {
        progress = false
        val unblocked = remaining.filter { tile -> !isArrowBlocked(tile, remaining) }
        if (unblocked.isNotEmpty()) {
            remaining.removeAll(unblocked)
            progress = true
        }
    }
    return remaining.isEmpty()
}

/**
 * Solvable puzzle generator for Arrow Escape:
 * Uses reverse-construction from outer edges toward the center, guaranteeing that every
 * single placed arrow has a clear, unblocked path to exit the screen in the correct sequence.
 * In addition, runs automated validation checks to eliminate facing arrows and verify 100% solvability.
 */
fun generateSolvablePuzzle(level: Int): Pair<Int, List<ArrowTile>> {
    val gridSize = when {
        level <= 2 -> 3
        level <= 4 -> 4
        else -> 5
    }
    val arrowCount = when {
        level == 1 -> 5
        level == 2 -> 7
        level == 3 -> 9
        level == 4 -> 12
        else -> minOf(13 + (level - 4), gridSize * gridSize - 2)
    }

    var attempt = 0
    val maxAttempts = 300

    while (attempt < maxAttempts) {
        val rand = Random(level.toLong() * 9973L + 12345L + attempt * 7919L)
        val candidateTiles = tryGenerateReverseBoard(level, gridSize, arrowCount, rand)
        if (candidateTiles != null &&
            candidateTiles.size == arrowCount &&
            !hasDirectlyFacingAdjacentArrows(candidateTiles) &&
            !hasHeadOnCollisions(candidateTiles) &&
            isBoard100PercentSolvable(gridSize, candidateTiles)
        ) {
            return Pair(gridSize, candidateTiles)
        }
        attempt++
    }

    // Mathematically guaranteed 100% winnable radial fallback
    return Pair(gridSize, generateGuaranteedRadialPuzzle(level, gridSize, arrowCount))
}

private fun tryGenerateReverseBoard(
    level: Int,
    gridSize: Int,
    arrowCount: Int,
    rand: Random
): List<ArrowTile>? {
    val maxLayers = (gridSize + 1) / 2
    val layerPositions = (0 until maxLayers).map { layerIndex ->
        val list = mutableListOf<Pair<Int, Int>>()
        for (r in 0 until gridSize) {
            for (c in 0 until gridSize) {
                val dist = minOf(r, gridSize - 1 - r, c, gridSize - 1 - c)
                if (dist == layerIndex) list.add(r to c)
            }
        }
        list.shuffled(rand).toMutableList()
    }

    // Distribute chosen positions across layers from outer to inner
    val selectedPositions = mutableListOf<Pair<Int, Int>>()
    val innerQuota = if (maxLayers > 1) minOf(arrowCount / 3, layerPositions.drop(1).sumOf { it.size }) else 0
    val outerQuota = (arrowCount - innerQuota).coerceAtMost(layerPositions[0].size)

    selectedPositions.addAll(layerPositions[0].take(outerQuota))
    var remaining = arrowCount - selectedPositions.size

    for (layer in 1 until maxLayers) {
        if (remaining <= 0) break
        val takeCount = minOf(remaining, layerPositions[layer].size)
        selectedPositions.addAll(layerPositions[layer].take(takeCount))
        remaining -= takeCount
    }
    if (remaining > 0) {
        val leftovers = layerPositions.flatten().filter { it !in selectedPositions }
        selectedPositions.addAll(leftovers.take(remaining))
    }

    // Sort positions so outer layer is placed backwards first toward the center
    selectedPositions.sortBy { (r, c) -> minOf(r, gridSize - 1 - r, c, gridSize - 1 - c) }

    val placedTiles = mutableListOf<ArrowTile>()

    for ((r, c) in selectedPositions) {
        val distToEdge = minOf(r, gridSize - 1 - r, c, gridSize - 1 - c)

        val candidateDirs = ArrowDirection.entries.shuffled(rand).filter { dir ->
            // Check adjacent tile
            val (adjR, adjC, oppDir) = when (dir) {
                ArrowDirection.UP -> Triple(r - 1, c, ArrowDirection.DOWN)
                ArrowDirection.DOWN -> Triple(r + 1, c, ArrowDirection.UP)
                ArrowDirection.LEFT -> Triple(r, c - 1, ArrowDirection.RIGHT)
                ArrowDirection.RIGHT -> Triple(r, c + 1, ArrowDirection.LEFT)
            }
            val adjTile = placedTiles.find { it.row == adjR && it.col == adjC }
            if (adjTile != null && adjTile.direction == oppDir) {
                return@filter false
            }

            // Check line of sight ahead
            val ray = when (dir) {
                ArrowDirection.UP -> (r - 1 downTo 0).map { it to c }
                ArrowDirection.DOWN -> (r + 1 until gridSize).map { it to c }
                ArrowDirection.LEFT -> (c - 1 downTo 0).map { r to it }
                ArrowDirection.RIGHT -> (c + 1 until gridSize).map { r to it }
            }
            val firstAhead = ray.firstNotNullOfOrNull { (rayR, rayC) ->
                placedTiles.find { it.row == rayR && it.col == rayC }
            }
            if (firstAhead != null && firstAhead.direction == oppDir) {
                return@filter false
            }

            true
        }

        if (candidateDirs.isEmpty()) {
            return null // Backtrack / regenerate
        }

        // Prefer outward-pointing directions for border tiles so initial exits exist
        val chosenDir = if (distToEdge == 0) {
            val outwardDir = when {
                r == 0 && ArrowDirection.UP in candidateDirs -> ArrowDirection.UP
                r == gridSize - 1 && ArrowDirection.DOWN in candidateDirs -> ArrowDirection.DOWN
                c == 0 && ArrowDirection.LEFT in candidateDirs -> ArrowDirection.LEFT
                c == gridSize - 1 && ArrowDirection.RIGHT in candidateDirs -> ArrowDirection.RIGHT
                else -> null
            }
            outwardDir ?: candidateDirs.first()
        } else {
            val bestInner = candidateDirs.firstOrNull { dir ->
                val ray = when (dir) {
                    ArrowDirection.UP -> (r - 1 downTo 0).map { it to c }
                    ArrowDirection.DOWN -> (r + 1 until gridSize).map { it to c }
                    ArrowDirection.LEFT -> (c - 1 downTo 0).map { r to it }
                    ArrowDirection.RIGHT -> (c + 1 until gridSize).map { r to it }
                }
                val firstAhead = ray.firstNotNullOfOrNull { (rayR, rayC) ->
                    placedTiles.find { it.row == rayR && it.col == rayC }
                }
                firstAhead == null || firstAhead.direction == dir || firstAhead.direction.ordinal % 2 != dir.ordinal % 2
            }
            bestInner ?: candidateDirs.first()
        }

        val colorIdx = (r * 3 + c * 2 + chosenDir.ordinal) % 5
        placedTiles.add(
            ArrowTile(
                id = "tile_${level}_${r}_${c}",
                row = r,
                col = c,
                direction = chosenDir,
                colorIndex = colorIdx
            )
        )
    }

    return placedTiles
}

private fun generateGuaranteedRadialPuzzle(
    level: Int,
    gridSize: Int,
    arrowCount: Int
): List<ArrowTile> {
    val allPositions = mutableListOf<Pair<Int, Int>>()
    for (r in 0 until gridSize) {
        for (c in 0 until gridSize) {
            allPositions.add(r to c)
        }
    }
    allPositions.sortBy { (r, c) -> minOf(r, gridSize - 1 - r, c, gridSize - 1 - c) }
    val chosen = allPositions.take(arrowCount)

    return chosen.mapIndexed { idx, (r, c) ->
        val dir = when {
            r == 0 -> ArrowDirection.UP
            r == gridSize - 1 -> ArrowDirection.DOWN
            c == 0 -> ArrowDirection.LEFT
            c == gridSize - 1 -> ArrowDirection.RIGHT
            r <= gridSize / 2 -> ArrowDirection.UP
            else -> ArrowDirection.DOWN
        }
        ArrowTile(
            id = "tile_${level}_${r}_${c}",
            row = r,
            col = c,
            direction = dir,
            colorIndex = (r * 2 + c + idx) % 5
        )
    }
}

@Composable
fun ArrowEscapeGameScreen(
    currentLevel: Int,
    coinBalance: Int,
    onBackClick: () -> Unit,
    onLevelCompleted: (level: Int, score: Int, wonCoins: Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var activeLevel by remember(currentLevel) { mutableStateOf(currentLevel) }
    var hearts by remember(activeLevel) { mutableStateOf(3) }
    var score by remember(activeLevel) { mutableStateOf(0) }

    var gridSize by remember(activeLevel) { mutableStateOf(3) }
    var activeTiles by remember(activeLevel) { mutableStateOf<List<ArrowTile>>(emptyList()) }

    var flyingTileIds by remember { mutableStateOf<Set<String>>(emptySet()) }
    var shakingTileId by remember { mutableStateOf<String?>(null) }
    var redFlashTileId by remember { mutableStateOf<String?>(null) }
    var floatingFeedback by remember { mutableStateOf<String?>(null) }

    var isGameOver by remember { mutableStateOf(false) }
    var showReviveAd by remember { mutableStateOf(false) }
    var showLevelCompleteAd by remember { mutableStateOf(false) }
    var showCelebrationDialog by remember { mutableStateOf(false) }
    var showAdRequiredDialog by remember { mutableStateOf(false) }
    var wonCoinsThisLevel by remember { mutableStateOf(0) }
    var userEarnedLevelRewardThisAd by remember { mutableStateOf(false) }
    var userEarnedReviveThisAd by remember { mutableStateOf(false) }

    val coroutineScope = rememberCoroutineScope()

    // Initialize board on activeLevel change
    LaunchedEffect(activeLevel) {
        val (size, tiles) = generateSolvablePuzzle(activeLevel)
        gridSize = size
        activeTiles = tiles
        hearts = 3
        isGameOver = false
        flyingTileIds = emptySet()
        shakingTileId = null
        redFlashTileId = null
        floatingFeedback = null
    }

    // Tap Handling
    fun onArrowTapped(tile: ArrowTile) {
        if (hearts <= 0 || isGameOver || showLevelCompleteAd || showCelebrationDialog) return
        if (flyingTileIds.contains(tile.id)) return

        val blocked = isArrowBlocked(tile, activeTiles)
        if (blocked) {
            // BLOCKED: Shake, red flash, deduct 1 life
            shakingTileId = tile.id
            redFlashTileId = tile.id
            hearts = (hearts - 1).coerceAtLeast(0)
            floatingFeedback = "-1 💔 Blocked!"

            coroutineScope.launch {
                delay(350)
                shakingTileId = null
                redFlashTileId = null
                delay(600)
                floatingFeedback = null
            }

            if (hearts <= 0) {
                coroutineScope.launch {
                    delay(300)
                    isGameOver = true
                }
            }
        } else {
            // VALID: Animate flying off-screen and remove from board
            score += 15
            flyingTileIds = flyingTileIds + tile.id

            coroutineScope.launch {
                delay(260) // wait for fly-off animation
                activeTiles = activeTiles.filter { it.id != tile.id }
                flyingTileIds = flyingTileIds - tile.id

                // When all arrows are cleared: Level Complete!
                if (activeTiles.isEmpty()) {
                    delay(200)
                    wonCoinsThisLevel = (1..50).random()
                    // Immediately trigger simulated 5-second Rewarded Ad screen
                    showLevelCompleteAd = true
                }
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF0F172A),
                        Color(0xFF1E1B4B),
                        Color(0xFF090D16)
                    )
                )
            )
            .testTag("arrow_escape_game_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Bar: Back button, Title, Balance
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.12f))
                        .testTag("game_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "ARROW ESCAPE",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "TAP AWAY PUZZLE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF38BDF8),
                        letterSpacing = 1.sp
                    )
                }

                // Coin Balance Badge
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color.White.copy(alpha = 0.15f))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.ic_coin_gold),
                        contentDescription = null,
                        tint = Color.Unspecified,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "$coinBalance",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = RewardGoldLight
                    )
                }
            }

            // Stats HUD: Level Badge, Hearts (3 Hearts total), Remaining count
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0x33FFFFFF)),
                border = BorderStroke(1.dp, Color(0x22FFFFFF))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Level Badge
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFF6366F1))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "LVL $activeLevel",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "${activeTiles.size} Left",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White.copy(alpha = 0.8f)
                        )
                    }

                    // Floating Heart Loss indicator
                    if (floatingFeedback != null) {
                        Text(
                            text = floatingFeedback!!,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFFF4757)
                        )
                    }

                    // 3 Hearts Indicator
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        for (i in 1..3) {
                            val hasHeart = i <= hearts
                            Icon(
                                imageVector = if (hasHeart) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                contentDescription = "Heart $i",
                                tint = if (hasHeart) Color(0xFFFF3366) else Color.White.copy(alpha = 0.3f),
                                modifier = Modifier
                                    .size(22.dp)
                                    .scale(if (hasHeart) 1f else 0.85f)
                            )
                        }
                    }
                }
            }

            // Main Puzzle Board Area
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                PuzzleBoard(
                    gridSize = gridSize,
                    activeTiles = activeTiles,
                    flyingTileIds = flyingTileIds,
                    shakingTileId = shakingTileId,
                    redFlashTileId = redFlashTileId,
                    onTileClick = { onArrowTapped(it) }
                )
            }
        }

        // ==========================================
        // 1. Mandatory Rewarded Ad Dialog (on Level Complete)
        // ==========================================
        if (showLevelCompleteAd) {
            RewardedAdDialog(
                rewardCoins = wonCoinsThisLevel,
                onUserEarnedReward = {
                    userEarnedLevelRewardThisAd = true
                },
                onAdDismissed = { earned ->
                    showLevelCompleteAd = false
                    if (earned && userEarnedLevelRewardThisAd) {
                        onLevelCompleted(activeLevel, score, wonCoinsThisLevel)
                        showCelebrationDialog = true
                        showAdRequiredDialog = false
                    } else {
                        showAdRequiredDialog = true
                    }
                    userEarnedLevelRewardThisAd = false
                },
                onDismissRequest = {
                    showLevelCompleteAd = false
                    if (!userEarnedLevelRewardThisAd) {
                        showAdRequiredDialog = true
                    }
                    userEarnedLevelRewardThisAd = false
                }
            )
        }

        // ==========================================
        // 1b. Ad Required Warning Dialog (when Ad skipped or dismissed early)
        // ==========================================
        if (showAdRequiredDialog && !showCelebrationDialog) {
            Dialog(
                onDismissRequest = { /* Keep open until user watches ad */ },
                properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth(0.92f)
                        .shadow(24.dp, RoundedCornerShape(26.dp)),
                    shape = RoundedCornerShape(26.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                    border = BorderStroke(2.dp, Color(0xFFF59E0B))
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFF59E0B).copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = Color(0xFFFBBF24),
                                modifier = Modifier.size(36.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "⚠️ Ad Required to Unlock",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "You cleared all arrows on Level $activeLevel! Watch the full video ad to unlock your random coins reward and proceed to Level ${activeLevel + 1}.",
                            fontSize = 13.sp,
                            color = Color.White.copy(alpha = 0.8f),
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        Button(
                            onClick = {
                                showAdRequiredDialog = false
                                showLevelCompleteAd = true
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = RewardGreen,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("watch_ad_claim_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = Color.White
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "WATCH FULL AD TO UNLOCK",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // ==========================================
        // 2. Rewarded Ad Dialog (on Revive)
        // ==========================================
        if (showReviveAd) {
            RewardedAdDialog(
                rewardCoins = 0,
                onUserEarnedReward = {
                    userEarnedReviveThisAd = true
                },
                onAdDismissed = { earned ->
                    showReviveAd = false
                    if (earned && userEarnedReviveThisAd) {
                        hearts = 3
                        isGameOver = false
                    }
                    userEarnedReviveThisAd = false
                },
                onDismissRequest = {
                    showReviveAd = false
                    userEarnedReviveThisAd = false
                }
            )
        }

        // ==========================================
        // 3. Celebration Popup (Level Complete)
        // ==========================================
        if (showCelebrationDialog) {
            Dialog(
                onDismissRequest = { /* keep open until Next Level */ },
                properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth(0.92f)
                        .shadow(24.dp, RoundedCornerShape(26.dp)),
                    shape = RoundedCornerShape(26.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                    border = BorderStroke(2.dp, Color(0xFF6366F1))
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Celebration Star Badge
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.radialGradient(
                                        listOf(RewardGold, Color(0xFFD97706))
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.EmojiEvents,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(42.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "🎉 Level $activeLevel Cleared!",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "Ad watched successfully! Your reward has been unlocked and credited to your wallet balance.",
                            fontSize = 13.sp,
                            color = Color.White.copy(alpha = 0.8f),
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Reward Badge
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color(0xFF0F172A))
                                .padding(horizontal = 20.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_coin_gold),
                                contentDescription = null,
                                tint = Color.Unspecified,
                                modifier = Modifier.size(26.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "+$wonCoinsThisLevel Coins Unlocked",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                color = RewardGoldLight
                            )
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        Button(
                            onClick = {
                                showCelebrationDialog = false
                                showAdRequiredDialog = false
                                activeLevel += 1
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF6366F1),
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("next_level_button")
                        ) {
                            Text(
                                text = "Next Level (Level ${activeLevel + 1}) →",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // ==========================================
        // 4. Out of Hearts (Game Over) Dialog
        // ==========================================
        if (isGameOver && hearts <= 0) {
            Dialog(
                onDismissRequest = { /* Must choose an option */ },
                properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth(0.92f)
                        .shadow(24.dp, RoundedCornerShape(26.dp)),
                    shape = RoundedCornerShape(26.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                    border = BorderStroke(2.dp, Color(0xFFFF4757))
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Broken Heart Icon
                        Box(
                            modifier = Modifier
                                .size(68.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFFF4757).copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.HeartBroken,
                                contentDescription = null,
                                tint = Color(0xFFFF4757),
                                modifier = Modifier.size(38.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "Out of Hearts!",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "You made 3 blocked taps. Watch a quick ad to revive with full 3 hearts, or restart the level!",
                            fontSize = 13.sp,
                            color = Color.White.copy(alpha = 0.8f),
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        // Option 1: Watch Ad to Revive
                        Button(
                            onClick = {
                                showReviveAd = true
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = RewardGreen,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("watch_ad_to_revive_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = Color.White
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Watch Ad to Revive (3 ❤️)",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Option 2: Restart Level
                        OutlinedButton(
                            onClick = {
                                val (size, tiles) = generateSolvablePuzzle(activeLevel)
                                gridSize = size
                                activeTiles = tiles
                                hearts = 3
                                isGameOver = false
                                flyingTileIds = emptySet()
                            },
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.3f)),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("restart_level_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = null,
                                tint = Color.White
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Restart Level",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Grid-based Puzzle Board Composable.
 */
@Composable
fun PuzzleBoard(
    gridSize: Int,
    activeTiles: List<ArrowTile>,
    flyingTileIds: Set<String>,
    shakingTileId: String?,
    redFlashTileId: String?,
    onTileClick: (ArrowTile) -> Unit,
    modifier: Modifier = Modifier
) {
    val cellSize = when (gridSize) {
        3 -> 74.dp
        4 -> 62.dp
        else -> 50.dp
    }
    val spacing = when (gridSize) {
        3 -> 10.dp
        4 -> 9.dp
        else -> 8.dp
    }
    val boardPadding = 16.dp

    val boardWidth = (cellSize * gridSize) + (spacing * (gridSize - 1)) + (boardPadding * 2)

    Card(
        modifier = modifier
            .width(boardWidth)
            .wrapContentHeight()
            .shadow(16.dp, RoundedCornerShape(24.dp)),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E243B)),
        border = BorderStroke(1.5.dp, Color(0xFF3B4468))
    ) {
        Box(
            modifier = Modifier.padding(boardPadding),
            contentAlignment = Alignment.Center
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(spacing)
            ) {
                for (r in 0 until gridSize) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(spacing)
                    ) {
                        for (c in 0 until gridSize) {
                            val tile = activeTiles.find { it.row == r && it.col == c }
                            if (tile != null) {
                                ArrowTileView(
                                    tile = tile,
                                    size = cellSize,
                                    isFlying = flyingTileIds.contains(tile.id),
                                    isShaking = shakingTileId == tile.id,
                                    isRedFlashing = redFlashTileId == tile.id,
                                    onClick = { onTileClick(tile) }
                                )
                            } else {
                                // Empty cell socket placeholder
                                Box(
                                    modifier = Modifier
                                        .size(cellSize)
                                        .clip(RoundedCornerShape(13.dp))
                                        .background(Color.White.copy(alpha = 0.04f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .clip(CircleShape)
                                            .background(Color.White.copy(alpha = 0.1f))
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Individual Arrow Tile with animations (shake, fly off-screen, red flash).
 */
@Composable
fun ArrowTileView(
    tile: ArrowTile,
    size: androidx.compose.ui.unit.Dp,
    isFlying: Boolean,
    isShaking: Boolean,
    isRedFlashing: Boolean,
    onClick: () -> Unit
) {
    // Shake animation
    val shakeOffset = remember { Animatable(0f) }
    LaunchedEffect(isShaking) {
        if (isShaking) {
            shakeOffset.animateTo(-10f, tween(50))
            shakeOffset.animateTo(10f, tween(50))
            shakeOffset.animateTo(-8f, tween(50))
            shakeOffset.animateTo(8f, tween(50))
            shakeOffset.animateTo(0f, tween(50))
        }
    }

    // Flying translation & fade animation
    val flyProgress by animateFloatAsState(
        targetValue = if (isFlying) 1f else 0f,
        animationSpec = tween(durationMillis = 260, easing = FastOutSlowInEasing),
        label = "fly"
    )

    val flyDistance = 1200f
    val offsetX = when (tile.direction) {
        ArrowDirection.LEFT -> -flyDistance * flyProgress
        ArrowDirection.RIGHT -> flyDistance * flyProgress
        else -> 0f
    }
    val offsetY = when (tile.direction) {
        ArrowDirection.UP -> -flyDistance * flyProgress
        ArrowDirection.DOWN -> flyDistance * flyProgress
        else -> 0f
    }
    val alpha = (1f - flyProgress).coerceIn(0f, 1f)
    val scale = 1f + (flyProgress * 0.15f)

    // Palette per tile
    val normalGradient = when (tile.colorIndex % 5) {
        0 -> listOf(Color(0xFF4F46E5), Color(0xFF3730A3)) // Indigo
        1 -> listOf(Color(0xFF0284C7), Color(0xFF0369A1)) // Cyan / Sky
        2 -> listOf(Color(0xFF059669), Color(0xFF047857)) // Emerald
        3 -> listOf(Color(0xFFD97706), Color(0xFFB45309)) // Amber
        else -> listOf(Color(0xFF8B5CF6), Color(0xFF6D28D9)) // Purple
    }

    val backgroundBrush = if (isRedFlashing) {
        Brush.linearGradient(listOf(Color(0xFFEF4444), Color(0xFFDC2626)))
    } else {
        Brush.linearGradient(normalGradient)
    }

    val borderColor = if (isRedFlashing) Color(0xFFFF8A80) else Color.White.copy(alpha = 0.35f)

    Box(
        modifier = Modifier
            .size(size)
            .offset(x = (offsetX + shakeOffset.value).dp, y = offsetY.dp)
            .scale(scale)
            .clip(RoundedCornerShape(13.dp))
            .background(backgroundBrush)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onClick() }
            .testTag("arrow_tile_${tile.row}_${tile.col}"),
        contentAlignment = Alignment.Center
    ) {
        // Inner border & glossy highlight
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(13.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(Color.White.copy(alpha = 0.25f), Color.Transparent)
                    )
                )
        )

        // Bold Directional Arrow Icon
        Icon(
            imageVector = Icons.Default.ArrowUpward,
            contentDescription = "Arrow pointing ${tile.direction}",
            tint = Color.White.copy(alpha = alpha),
            modifier = Modifier
                .size(size * 0.52f)
                .rotate(tile.direction.rotationDeg)
        )
    }
}
