package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.*

enum class BottomTab(val title: String, val testTag: String) {
    GAME("Game", "tab_game"),
    TASK("Task", "tab_task"),
    WALLET("Wallet", "tab_wallet"),
    HISTORY("History", "tab_history"),
    PROFILE("Profile", "tab_profile")
}

@Composable
fun PlayAndEarnBottomNav(
    currentTab: BottomTab,
    onTabSelected: (BottomTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .shadow(16.dp, RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp), spotColor = Color(0x140F172A))
            .clip(RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp)),
        color = Color.White,
        border = BorderStroke(1.dp, CardBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 8.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            BottomTab.values().forEach { tab ->
                val isSelected = currentTab == tab
                
                val iconColor by animateColorAsState(
                    targetValue = if (isSelected) BrandPurplePrimary else TextMuted,
                    animationSpec = spring(),
                    label = "nav_icon_color"
                )

                val backgroundColor by animateColorAsState(
                    targetValue = if (isSelected) BrandPurpleLight else Color.Transparent,
                    animationSpec = spring(),
                    label = "nav_bg_color"
                )

                Column(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(backgroundColor)
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { onTabSelected(tab) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .testTag(tab.testTag),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    when (tab) {
                        BottomTab.GAME -> {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_gamepad),
                                contentDescription = tab.title,
                                tint = if (isSelected) BrandPurplePrimary else TextMuted,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        BottomTab.TASK -> {
                            Icon(
                                imageVector = if (isSelected) Icons.Filled.Assignment else Icons.Outlined.Assignment,
                                contentDescription = tab.title,
                                tint = iconColor,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        BottomTab.WALLET -> {
                            Icon(
                                imageVector = if (isSelected) Icons.Filled.AccountBalanceWallet else Icons.Outlined.AccountBalanceWallet,
                                contentDescription = tab.title,
                                tint = iconColor,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        BottomTab.HISTORY -> {
                            Icon(
                                imageVector = if (isSelected) Icons.Filled.ReceiptLong else Icons.Outlined.ReceiptLong,
                                contentDescription = tab.title,
                                tint = iconColor,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        BottomTab.PROFILE -> {
                            Icon(
                                imageVector = if (isSelected) Icons.Filled.Person else Icons.Outlined.PersonOutline,
                                contentDescription = tab.title,
                                tint = iconColor,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = tab.title,
                        fontSize = 10.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) BrandPurplePrimary else TextMuted
                    )
                }
            }
        }
    }
}

