package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.R
import com.example.ads.AdConfig
import com.example.ui.theme.*
import kotlinx.coroutines.delay

@Composable
fun RewardedAdDialog(
    rewardCoins: Int = 5,
    onUserEarnedReward: (coins: Int) -> Unit = {},
    onAdDismissed: (rewardEarned: Boolean) -> Unit = {},
    onAdCompleted: (() -> Unit)? = null,
    onAdSkippedOrClosed: (() -> Unit)? = null,
    onDismissRequest: () -> Unit = {}
) {
    var timeLeft by remember { mutableStateOf(AdConfig.REWARDED_AD_DURATION_SECONDS) }
    var isAdFinished by remember { mutableStateOf(false) }
    var showSkipWarning by remember { mutableStateOf(false) }
    var isMuted by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (timeLeft > 0) {
            delay(1000L)
            timeLeft -= 1
        }
        isAdFinished = true
        onUserEarnedReward(rewardCoins)
        onAdCompleted?.invoke()
    }

    Dialog(
        onDismissRequest = {
            if (isAdFinished) {
                onAdDismissed(true)
                onDismissRequest()
            } else {
                showSkipWarning = true
            }
        },
        properties = DialogProperties(
            dismissOnBackPress = false,
            dismissOnClickOutside = false,
            usePlatformDefaultWidth = false
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.95f))
                .testTag("rewarded_ad_fullscreen"),
            contentAlignment = Alignment.Center
        ) {
            // Main Ad Container
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Top Header: AdMob Test Badge, Timer & Close button
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // AdMob Test Notice Pill
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.White.copy(alpha = 0.2f))
                            .padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "AdMob Test Ad",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Yellow
                        )
                    }

                    // Sound & Timer / Close
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        IconButton(
                            onClick = { isMuted = !isMuted },
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.2f))
                        ) {
                            Icon(
                                imageVector = if (isMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                                contentDescription = if (isMuted) "Audio Muted" else "Audio On",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        if (!isAdFinished) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.White.copy(alpha = 0.25f))
                                    .padding(horizontal = 12.dp, vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "Reward in ${timeLeft}s",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        } else {
                            IconButton(
                                onClick = {
                                    onAdDismissed(true)
                                    onDismissRequest()
                                },
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(RewardGreen)
                                    .testTag("ad_close_claim_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Claim and Close",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }

                // Middle: Visual Ad Video Player Simulation
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.9f)
                        .weight(1f)
                        .padding(vertical = 16.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    Color(0xFF2C3E50),
                                    Color(0xFF1E272E),
                                    Color(0xFF0F172A)
                                )
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier.padding(24.dp)
                    ) {
                        // Animated pulsing Game Controller icon
                        Box(
                            modifier = Modifier
                                .size(110.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.radialGradient(
                                        listOf(
                                            BrandPurplePrimary.copy(alpha = 0.5f),
                                            Color.Transparent
                                        )
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_gamepad),
                                contentDescription = null,
                                tint = Color.Unspecified,
                                modifier = Modifier.size(80.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Text(
                            text = "Play & Earn Rewards",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "Play casual games every day to earn instant cash and real gift cards!",
                            fontSize = 13.sp,
                            color = Color.White.copy(alpha = 0.8f),
                            textAlign = TextAlign.Center,
                            lineHeight = 18.sp
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        // Live progress bar
                        val progress = (AdConfig.REWARDED_AD_DURATION_SECONDS - timeLeft).toFloat() / AdConfig.REWARDED_AD_DURATION_SECONDS.toFloat()
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier
                                .fillMaxWidth(0.8f)
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = RewardGreen,
                            trackColor = Color.White.copy(alpha = 0.2f),
                        )
                    }
                }

                // Bottom CTA & Claim Bar
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (isAdFinished) {
                        Button(
                            onClick = {
                                onAdDismissed(true)
                                onDismissRequest()
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = RewardGreen,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("claim_ad_reward_button")
                        ) {
                            if (rewardCoins > 0) {
                                Icon(
                                    painter = painterResource(id = R.drawable.ic_coin_gold),
                                    contentDescription = null,
                                    tint = Color.Unspecified,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "CLAIM +$rewardCoins COINS & CONTINUE",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            } else {
                                Text(
                                    text = "CONTINUE & REVIVE (3 ❤️)",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    } else {
                        TextButton(
                            onClick = { showSkipWarning = true }
                        ) {
                            Text(
                                text = "Skip Ad",
                                fontSize = 12.sp,
                                color = Color.White.copy(alpha = 0.6f)
                            )
                        }
                    }
                }
            }

            // Skip Warning Dialog
            if (showSkipWarning && !isAdFinished) {
                AlertDialog(
                    onDismissRequest = { showSkipWarning = false },
                    title = {
                        Text("Skip Video Ad?", fontWeight = FontWeight.Bold)
                    },
                    text = {
                        Text(
                            if (rewardCoins > 0)
                                "If you skip the ad now (${timeLeft}s remaining), you will NOT receive the +$rewardCoins coins reward and the next level will remain locked."
                            else
                                "If you skip the ad now, your game will not be revived."
                        )
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                showSkipWarning = false
                                onAdDismissed(false)
                                onAdSkippedOrClosed?.invoke()
                                onDismissRequest()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = RewardRed)
                        ) {
                            Text("Skip Anyway")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showSkipWarning = false }) {
                            Text("Resume Video")
                        }
                    }
                )
            }
        }
    }
}
