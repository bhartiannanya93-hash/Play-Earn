package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.R
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class TapParticle(val id: Long, val xOffset: Float, val yOffset: Float)

@Composable
fun TapCoinGameScreen(
    currentLevel: Int,
    coinBalance: Int,
    rewardCoinsPerLevel: Int = 5,
    onBackClick: () -> Unit,
    onWatchAdAndClaim: (level: Int, score: Int, rewardCoins: Int, onAdRewardDone: () -> Unit) -> Unit,
    modifier: Modifier = Modifier
) {
    var activeLevel by remember(currentLevel) { mutableStateOf(currentLevel) }
    val targetTaps = remember(activeLevel) { 10 + (activeLevel - 1) * 5 }
    var currentTaps by remember(activeLevel) { mutableStateOf(0) }
    var isTargetReached by remember(activeLevel) { mutableStateOf(false) }
    var isAdWatchedAndClosed by remember(activeLevel) { mutableStateOf(false) }
    var showCelebrationDialog by remember(activeLevel) { mutableStateOf(false) }
    var wonCoinsThisLevel by remember(activeLevel) { mutableStateOf((1..50).random()) }

    val coroutineScope = rememberCoroutineScope()
    var coinScale by remember { mutableStateOf(1f) }
    var particles by remember { mutableStateOf(listOf<TapParticle>()) }

    // Tap Handling
    fun onCoinTapped() {
        if (isTargetReached || showCelebrationDialog) return
        
        currentTaps += 1
        
        // Scale bounce animation
        coinScale = 0.88f
        coroutineScope.launch {
            delay(80)
            coinScale = 1.08f
            delay(80)
            coinScale = 1f
        }

        // Add float particle
        val p = TapParticle(
            id = System.nanoTime(),
            xOffset = (-40..40).random().toFloat(),
            yOffset = (-60..-20).random().toFloat()
        )
        particles = particles + p

        if (currentTaps >= targetTaps && !isTargetReached) {
            isTargetReached = true
            wonCoinsThisLevel = (1..50).random()
            // Mandatory Ad Trigger before Level Cleared Victory Dialog
            onWatchAdAndClaim(activeLevel, currentTaps, wonCoinsThisLevel) {
                isAdWatchedAndClosed = true
                showCelebrationDialog = true
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF2C1654),
                        Color(0xFF1E1035),
                        Color(0xFF0F081D)
                    )
                )
            )
            .testTag("tap_coin_game_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Bar: Back button, Title, Coin Balance
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.15f))
                        .testTag("game_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }

                Text(
                    text = "TAP TAP",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    letterSpacing = 1.sp
                )

                // Top Right Coin Balance
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color.White.copy(alpha = 0.15f))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.ic_coin_gold),
                        contentDescription = null,
                        tint = Color.Unspecified,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "$coinBalance",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = RewardGoldLight
                    )
                }
            }

            // Center: Level info, Coin & Progress
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.weight(1f)
            ) {
                // Level Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(BrandPurplePrimary)
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "Level $activeLevel",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Tap the coin $targetTaps times to complete the level!",
                    fontSize = 13.sp,
                    color = Color.White.copy(alpha = 0.8f),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(30.dp))

                // Big Animated Coin
                Box(
                    modifier = Modifier
                        .size(220.dp)
                        .scale(coinScale)
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { onCoinTapped() }
                        .testTag("interactive_coin_target"),
                    contentAlignment = Alignment.Center
                ) {
                    // Glow background
                    Box(
                        modifier = Modifier
                            .size(200.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    listOf(RewardGold.copy(alpha = 0.4f), Color.Transparent)
                                )
                            )
                    )

                    Icon(
                        painter = painterResource(id = R.drawable.ic_coin_gold),
                        contentDescription = "Tap Coin",
                        tint = Color.Unspecified,
                        modifier = Modifier.size(170.dp)
                    )

                    // Particle sparkles
                    particles.takeLast(4).forEach { p ->
                        Text(
                            text = "+1 ⚡",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            color = RewardGoldLight,
                            modifier = Modifier.offset(x = p.xOffset.dp, y = p.yOffset.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(30.dp))

                // Progress Bar
                val progressFraction = (currentTaps.toFloat() / targetTaps.toFloat()).coerceIn(0f, 1f)
                Column(
                    modifier = Modifier.fillMaxWidth(0.85f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    LinearProgressIndicator(
                        progress = { progressFraction },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(14.dp)
                            .clip(RoundedCornerShape(8.dp)),
                        color = RewardGold,
                        trackColor = Color.White.copy(alpha = 0.2f)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "$currentTaps / $targetTaps Taps",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }

            // Bottom Level Complete / Rewarded Ad Action Area
            AnimatedVisibility(
                visible = isTargetReached && !isAdWatchedAndClosed,
                enter = fadeIn() + slideInVertically { it / 2 }
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(16.dp, RoundedCornerShape(24.dp)),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                    border = BorderStroke(1.5.dp, Color(0xFFF59E0B))
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "⚠️ AD REQUIRED TO UNLOCK NEXT LEVEL",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black,
                            color = Color(0xFFFBBF24),
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "You reached the tap goal for Level $activeLevel! Watch the full video ad to unlock your random coins reward and advance to Level ${activeLevel + 1}.",
                            fontSize = 13.sp,
                            color = Color.White.copy(alpha = 0.8f),
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                onWatchAdAndClaim(activeLevel, currentTaps, wonCoinsThisLevel) {
                                    isAdWatchedAndClosed = true
                                    showCelebrationDialog = true
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = RewardGreen,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("watch_ad_claim_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "WATCH FULL AD TO UNLOCK LEVEL",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Victory Dialog - ONLY shown after ad is fully watched and closed
        if (showCelebrationDialog && isAdWatchedAndClosed) {
            Dialog(
                onDismissRequest = { /* Must click Next Level to advance */ },
                properties = DialogProperties(
                    dismissOnBackPress = false,
                    dismissOnClickOutside = false
                )
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth(0.95f)
                        .shadow(24.dp, RoundedCornerShape(26.dp)),
                    shape = RoundedCornerShape(26.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                    border = BorderStroke(2.dp, BrandPurplePrimary)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.radialGradient(
                                        listOf(RewardGold, Color(0xFFD97706))
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.EmojiEvents,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(42.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "🎉 Level $activeLevel Cleared!",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "Ad watched successfully! Your reward has been unlocked and credited to your wallet balance.",
                            fontSize = 13.sp,
                            color = Color.White.copy(alpha = 0.8f),
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Unlocked Coins Reward Badge
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color(0xFF0F172A))
                                .padding(horizontal = 20.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_coin_gold),
                                contentDescription = null,
                                tint = Color.Unspecified,
                                modifier = Modifier.size(26.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "+$wonCoinsThisLevel Coins Unlocked",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                color = RewardGoldLight
                            )
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        Button(
                            onClick = {
                                showCelebrationDialog = false
                                isAdWatchedAndClosed = false
                                isTargetReached = false
                                activeLevel += 1
                                currentTaps = 0
                                wonCoinsThisLevel = (1..50).random()
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = BrandPurplePrimary,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("next_level_button")
                        ) {
                            Text(
                                text = "Next Level (Level ${activeLevel + 1}) →",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
