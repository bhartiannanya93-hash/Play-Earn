package com.example.ui.navigation

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.ui.theme.PlayAndEarnTheme
import com.example.ui.theme.ScreenBackground
import com.example.ui.viewmodel.ActiveScreen
import com.example.ui.viewmodel.RewardsViewModel

@Composable
fun PlayAndEarnApp(
    viewModel: RewardsViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    var showNotificationDialog by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.snackbarMessage) {
        uiState.snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.dismissSnackbar()
        }
    }

    PlayAndEarnTheme {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            bottomBar = {
                if (uiState.activeScreen == ActiveScreen.Main) {
                    PlayAndEarnBottomNav(
                        currentTab = uiState.currentTab,
                        onTabSelected = { tab -> viewModel.selectTab(tab) }
                    )
                }
            },
            containerColor = ScreenBackground
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(
                        bottom = if (uiState.activeScreen == ActiveScreen.Main) paddingValues.calculateBottomPadding() else androidx.compose.ui.unit.Dp.Unspecified
                    )
            ) {
                // Navigation Screen Router
                when (val screen = uiState.activeScreen) {
                    is ActiveScreen.Main -> {
                        when (uiState.currentTab) {
                            BottomTab.GAME -> {
                                HomeScreen(
                                    uiState = uiState,
                                    onWithdrawClick = { viewModel.navigateTo(ActiveScreen.Withdraw) },
                                    onPlayGamesClick = { viewModel.navigateTo(ActiveScreen.GamePlay("all_games")) },
                                    onLaunchGame = { gameId -> viewModel.navigateTo(ActiveScreen.GamePlay(gameId)) },
                                    onTaskActionClick = { taskId, route ->
                                        if (route == "game") {
                                            viewModel.navigateTo(ActiveScreen.GamePlay("all_games"))
                                        } else if (taskId == "task_watch_ad") {
                                            viewModel.launchRewardedAd(3) {
                                                viewModel.claimTask(taskId)
                                            }
                                        } else {
                                            viewModel.claimTask(taskId)
                                        }
                                    },
                                    onNotificationClick = { showNotificationDialog = true },
                                    onProfileClick = { viewModel.selectTab(BottomTab.PROFILE) }
                                )
                            }
                            BottomTab.TASK -> {
                                TaskScreen(
                                    uiState = uiState,
                                    onClaimTask = { taskId -> viewModel.claimTask(taskId) },
                                    onNavigateToRoute = { route ->
                                        if (route == "game") viewModel.navigateTo(ActiveScreen.GamePlay("all_games"))
                                        else viewModel.selectTab(BottomTab.GAME)
                                    },
                                    onWatchAdTask = {
                                        viewModel.launchRewardedAd(3) {
                                            viewModel.claimTask("task_watch_ad")
                                        }
                                    },
                                    onNotificationClick = { showNotificationDialog = true },
                                    onProfileClick = { viewModel.selectTab(BottomTab.PROFILE) }
                                )
                            }
                            BottomTab.WALLET -> {
                                WalletScreen(
                                    uiState = uiState,
                                    onWithdrawClick = { viewModel.navigateTo(ActiveScreen.Withdraw) },
                                    onNotificationClick = { showNotificationDialog = true },
                                    onProfileClick = { viewModel.selectTab(BottomTab.PROFILE) }
                                )
                            }
                            BottomTab.HISTORY -> {
                                HistoryScreen(
                                    uiState = uiState,
                                    onNotificationClick = { showNotificationDialog = true },
                                    onProfileClick = { viewModel.selectTab(BottomTab.PROFILE) }
                                )
                            }
                            BottomTab.PROFILE -> {
                                ProfileScreen(
                                    uiState = uiState,
                                    onReferralClick = { viewModel.navigateTo(ActiveScreen.Referral) },
                                    onLogoutClick = { viewModel.logout() }
                                )
                            }
                        }
                    }

                    is ActiveScreen.Withdraw -> {
                        WithdrawScreen(
                            uiState = uiState,
                            onBackClick = { viewModel.navigateBack() },
                            onSubmitWithdrawal = { amount, method, holder, upiOrAccount, ifsc ->
                                viewModel.requestWithdrawal(amount, method, holder, upiOrAccount, ifsc) {
                                    viewModel.navigateBack()
                                }
                            }
                        )
                    }

                    is ActiveScreen.Referral -> {
                        ReferralScreen(
                            uiState = uiState,
                            onBackClick = { viewModel.navigateBack() }
                        )
                    }

                    is ActiveScreen.Admin -> {
                        AdminScreen(
                            viewModel = viewModel,
                            uiState = uiState,
                            onBackClick = { viewModel.navigateBack() }
                        )
                    }

                    is ActiveScreen.Auth -> {
                        AuthScreen(
                            onLoginSuccess = { email, name, phone, password, refCode ->
                                viewModel.login(email, name, phone, password, refCode)
                            },
                            isLoading = uiState.isLoading,
                            authErrorMessage = uiState.authErrorMessage,
                            onClearAuthError = { viewModel.clearAuthError() }
                        )
                    }

                    is ActiveScreen.GamePlay -> {
                        val progress = uiState.gamesProgress.find { it.gameId == screen.gameId }
                        val level = progress?.currentLevel ?: 1
                        val balance = uiState.wallet?.balanceCoins ?: 1255

                        when (screen.gameId) {
                            "arrow_escape" -> {
                                ArrowEscapeGameScreen(
                                    currentLevel = level,
                                    coinBalance = balance,
                                    onBackClick = { viewModel.navigateBack() },
                                    onLevelCompleted = { lvl, score, wonCoins ->
                                        viewModel.completeGameLevel(
                                            gameId = "arrow_escape",
                                            levelCompleted = lvl,
                                            score = score,
                                            claimedWithAd = true,
                                            customRewardCoins = wonCoins
                                        )
                                    }
                                )
                            }
                            "tap_coin" -> {
                                TapCoinGameScreen(
                                    currentLevel = level,
                                    coinBalance = balance,
                                    rewardCoinsPerLevel = uiState.appConfig.tapCoinRewardCoins,
                                    onBackClick = { viewModel.navigateBack() },
                                    onWatchAdAndClaim = { lvl, score, wonCoins, onAdRewardDone ->
                                        viewModel.launchRewardedAd(wonCoins) {
                                            viewModel.completeGameLevel(
                                                gameId = "tap_coin",
                                                levelCompleted = lvl,
                                                score = score,
                                                claimedWithAd = true,
                                                customRewardCoins = wonCoins
                                            )
                                            onAdRewardDone()
                                        }
                                    }
                                )
                            }
                            "color_match" -> {
                                ColorMatchGameScreen(
                                    currentLevel = level,
                                    coinBalance = balance,
                                    rewardCoinsPerLevel = uiState.appConfig.colorMatchRewardCoins,
                                    onBackClick = { viewModel.navigateBack() },
                                    onWatchAdAndClaim = { lvl, score, onAdRewardDone ->
                                        viewModel.launchRewardedAd(uiState.appConfig.colorMatchRewardCoins) {
                                            viewModel.completeGameLevel("color_match", lvl, score, true)
                                            onAdRewardDone()
                                        }
                                    }
                                )
                            }
                            "catch_candy" -> {
                                CatchCandyGameScreen(
                                    currentLevel = level,
                                    coinBalance = balance,
                                    rewardCoinsPerLevel = uiState.appConfig.catchCandyRewardCoins,
                                    onBackClick = { viewModel.navigateBack() },
                                    onWatchAdAndClaim = { lvl, score, onAdRewardDone ->
                                        viewModel.launchRewardedAd(uiState.appConfig.catchCandyRewardCoins) {
                                            viewModel.completeGameLevel("catch_candy", lvl, score, true)
                                            onAdRewardDone()
                                        }
                                    }
                                )
                            }
                            else -> {
                                GameScreen(
                                    uiState = uiState,
                                    onLaunchGame = { gId -> viewModel.navigateTo(ActiveScreen.GamePlay(gId)) },
                                    onNotificationClick = { showNotificationDialog = true },
                                    onProfileClick = { viewModel.selectTab(BottomTab.PROFILE) }
                                )
                            }
                        }
                    }
                }

                // Notifications Dialog
                if (showNotificationDialog) {
                    NotificationDialog(
                        notifications = uiState.notifications,
                        onDismiss = { showNotificationDialog = false },
                        onMarkAllRead = { viewModel.markAllNotificationsRead() }
                    )
                }

                // Rewarded Ad Dialog (Google AdMob rewarded video flow)
                if (uiState.isShowingRewardedAd) {
                    RewardedAdDialog(
                        rewardCoins = uiState.pendingAdRewardCoins,
                        onUserEarnedReward = { coins -> viewModel.onUserEarnedReward(coins) },
                        onAdDismissed = { earned -> viewModel.onRewardedAdDismissed(earned) },
                        onDismissRequest = { viewModel.onRewardedAdDismissed(false) }
                    )
                }
            }
        }
    }
}
