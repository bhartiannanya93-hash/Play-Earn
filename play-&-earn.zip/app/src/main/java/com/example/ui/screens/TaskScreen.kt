package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.TaskEntity
import com.example.ui.components.EmptyStateView
import com.example.ui.components.PlayAndEarnTopBar
import com.example.ui.components.TaskItemCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.UserUiState

@Composable
fun TaskScreen(
    uiState: UserUiState,
    onClaimTask: (String) -> Unit,
    onNavigateToRoute: (String) -> Unit,
    onWatchAdTask: () -> Unit,
    onNotificationClick: () -> Unit,
    onProfileClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val coreTasks = remember(uiState.tasks) {
        val filtered = uiState.tasks.filter { task ->
            task.id != "task_complete_level" &&
            task.id != "task_daily_challenge" &&
            !task.title.contains("Complete Game Level", ignoreCase = true) &&
            !task.title.contains("Daily Challenge", ignoreCase = true)
        }
        val orderMap = mapOf(
            "task_daily_checkin" to 1,
            "task_watch_ad" to 2,
            "task_play_game" to 3
        )
        filtered.sortedBy { orderMap[it.id] ?: 99 }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ScreenBackground)
            .testTag("task_screen"),
        contentPadding = PaddingValues(bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            PlayAndEarnTopBar(
                userName = uiState.currentUser?.name ?: "Suman Kumar",
                unreadNotifCount = uiState.unreadNotifCount,
                onNotificationClick = onNotificationClick,
                onProfileClick = onProfileClick
            )
        }

        // Header Title
        item {
            Column(modifier = Modifier.padding(horizontal = 20.dp)) {
                Text(
                    text = "Daily Tasks",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = TextPrimary
                )
                Text(
                    text = "Complete your daily tasks to earn coins and cash",
                    fontSize = 13.sp,
                    color = TextSecondary
                )
            }
        }

        // Core Task Cards List
        if (coreTasks.isEmpty()) {
            item {
                EmptyStateView(
                    title = "No Tasks Available",
                    message = "Check back soon for brand new daily tasks!",
                    iconRes = R.drawable.ic_daily_checkin
                )
            }
        } else {
            items(coreTasks) { task ->
                Box(modifier = Modifier.padding(horizontal = 20.dp)) {
                    TaskItemCard(
                        task = task,
                        onActionClick = {
                            if (task.iconType == "checkin") {
                                onClaimTask(task.id)
                            } else if (task.iconType == "ad") {
                                onWatchAdTask()
                            } else {
                                onNavigateToRoute(task.actionRoute)
                            }
                        }
                    )
                }
            }
        }
    }
}
