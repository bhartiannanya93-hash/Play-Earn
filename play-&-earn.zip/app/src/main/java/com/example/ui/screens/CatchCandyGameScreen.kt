package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.random.Random

data class FallingCandy(
    val id: Long,
    var x: Float, // 0f to 1f normalized screen width
    var y: Float, // 0f to 1f normalized screen height
    val speed: Float,
    val color: Color,
    val points: Int,
    val radius: Float = 22f
)

@Composable
fun CatchCandyGameScreen(
    currentLevel: Int,
    coinBalance: Int,
    rewardCoinsPerLevel: Int = 5,
    onBackClick: () -> Unit,
    onWatchAdAndClaim: (level: Int, score: Int, onAdRewardDone: () -> Unit) -> Unit,
    modifier: Modifier = Modifier
) {
    var activeLevel by remember(currentLevel) { mutableStateOf(currentLevel) }
    val targetScore = remember(activeLevel) { 40 + (activeLevel - 1) * 15 }
    var score by remember(activeLevel) { mutableStateOf(0) }
    var isLevelComplete by remember { mutableStateOf(false) }
    var isRewardClaimed by remember { mutableStateOf(false) }

    // Player basket X position normalized (0.1 to 0.9)
    var basketX by remember { mutableStateOf(0.5f) }
    var candies by remember { mutableStateOf(listOf<FallingCandy>()) }

    val candyColors = listOf(
        Pair(Color(0xFFFF4757), 10),
        Pair(Color(0xFFFFA502), 10),
        Pair(Color(0xFF2ED573), 10),
        Pair(Color(0xFF1E90FF), 10),
        Pair(Color(0xFFFFD32A), 25) // Gold bonus candy
    )

    // Game loop
    LaunchedEffect(activeLevel, isLevelComplete) {
        var lastSpawnTime = 0L
        while (!isLevelComplete) {
            val now = System.currentTimeMillis()
            
            // Spawn candy every 600ms - 900ms
            if (now - lastSpawnTime > maxOf(400L, 800L - (activeLevel * 30L))) {
                val colorPoint = candyColors.random()
                val newCandy = FallingCandy(
                    id = System.nanoTime(),
                    x = Random.nextFloat() * 0.8f + 0.1f,
                    y = 0.05f,
                    speed = 0.012f + (activeLevel * 0.002f),
                    color = colorPoint.first,
                    points = colorPoint.second
                )
                candies = candies + newCandy
                lastSpawnTime = now
            }

            // Update candy positions & detect catch
            val updated = mutableListOf<FallingCandy>()
            var caughtPoints = 0

            for (c in candies) {
                c.y += c.speed
                // Check if caught in basket (basket is at y ~ 0.85, width ~ 0.22)
                if (c.y >= 0.80f && c.y <= 0.90f) {
                    if (kotlin.math.abs(c.x - basketX) < 0.14f) {
                        caughtPoints += c.points
                        continue // Caught! Don't keep falling
                    }
                }
                // Keep if still on screen
                if (c.y < 1.0f) {
                    updated.add(c)
                }
            }

            if (caughtPoints > 0) {
                score += caughtPoints
                if (score >= targetScore) {
                    isLevelComplete = true
                }
            }

            candies = updated
            delay(30L)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF2D142C),
                        Color(0xFF510A32),
                        Color(0xFF801336)
                    )
                )
            )
            .testTag("catch_candy_game_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.15f))
                        .testTag("game_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }

                Text(
                    text = "CATCH CANDY",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    letterSpacing = 1.sp
                )

                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color.White.copy(alpha = 0.15f))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.ic_coin_gold),
                        contentDescription = null,
                        tint = Color.Unspecified,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "$coinBalance",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = RewardGoldLight
                    )
                }
            }

            // Game Info Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFFFF4757))
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "Level $activeLevel",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Text(
                    text = "Score: $score / $targetScore",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = RewardGoldLight
                )
            }

            // Canvas Game Viewport (Draggable Basket + Candies)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.Black.copy(alpha = 0.25f))
                    .pointerInput(Unit) {
                        detectDragGestures { change, _ ->
                            val newNormX = (change.position.x / size.width.toFloat()).coerceIn(0.12f, 0.88f)
                            basketX = newNormX
                        }
                    }
                    .pointerInput(Unit) {
                        detectTapGestures { offset ->
                            val newNormX = (offset.x / size.width.toFloat()).coerceIn(0.12f, 0.88f)
                            basketX = newNormX
                        }
                    }
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height

                    // Draw falling candies
                    for (c in candies) {
                        drawCircle(
                            color = c.color,
                            radius = c.radius,
                            center = Offset(c.x * w, c.y * h)
                        )
                        // Inner glossy shine
                        drawCircle(
                            color = Color.White.copy(alpha = 0.6f),
                            radius = c.radius * 0.35f,
                            center = Offset(c.x * w - c.radius * 0.3f, c.y * h - c.radius * 0.3f)
                        )
                    }

                    // Draw Basket at bottom
                    val basketWidth = w * 0.26f
                    val basketHeight = 28f
                    val basketLeft = (basketX * w) - (basketWidth / 2f)
                    val basketTop = h * 0.85f

                    // Basket Body
                    drawRoundRect(
                        color = Color(0xFFFECA57),
                        topLeft = Offset(basketLeft, basketTop),
                        size = Size(basketWidth, basketHeight),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(14f, 14f)
                    )

                    // Basket Trim
                    drawRoundRect(
                        color = Color(0xFFFF9F43),
                        topLeft = Offset(basketLeft + 6f, basketTop + 6f),
                        size = Size(basketWidth - 12f, basketHeight - 12f),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f)
                    )
                }

                // Drag hint
                Text(
                    text = "👈 Drag Basket to Catch Candies 👉",
                    fontSize = 12.sp,
                    color = Color.White.copy(alpha = 0.5f),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 12.dp)
                )
            }

            // Bottom Level Complete
            AnimatedVisibility(
                visible = isLevelComplete,
                enter = fadeIn() + slideInVertically { it / 2 }
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(16.dp, RoundedCornerShape(24.dp)),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "🎉 LEVEL $activeLevel COMPLETE!",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "Reward: +$rewardCoinsPerLevel Coins",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = RewardGoldLight
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        if (!isRewardClaimed) {
                            Button(
                                onClick = {
                                    onWatchAdAndClaim(activeLevel, score) {
                                        isRewardClaimed = true
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = RewardGreen,
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("watch_ad_claim_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = null
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "WATCH AD & CLAIM REWARD",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        } else {
                            Button(
                                onClick = {
                                    activeLevel += 1
                                    score = 0
                                    candies = emptyList()
                                    isLevelComplete = false
                                    isRewardClaimed = false
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFFFF4757),
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("next_level_button")
                            ) {
                                Text(
                                    text = "Next Level (Level ${activeLevel + 1}) →",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
