package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.*

@Composable
fun AuthScreen(
    onLoginSuccess: (email: String, name: String, phone: String, password: String, refCode: String?) -> Unit,
    modifier: Modifier = Modifier,
    isLoading: Boolean = false,
    authErrorMessage: String? = null,
    onClearAuthError: () -> Unit = {}
) {
    var isRegisterMode by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var referralCode by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(authErrorMessage) {
        if (!authErrorMessage.isNullOrBlank()) {
            errorMessage = authErrorMessage
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ScreenBackground)
            .testTag("auth_screen")
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // App Branding Header
            item {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(BrandPurplePrimary, BrandBlue)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.ic_coin_gold),
                        contentDescription = "Play & Earn Logo",
                        tint = Color.Unspecified,
                        modifier = Modifier.size(54.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Play & Earn",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Black,
                    color = TextPrimary
                )

                Text(
                    text = "Play Games • Complete Tasks • Earn Rewards",
                    fontSize = 13.sp,
                    color = TextSecondary,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(28.dp))
            }

            // Auth Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(8.dp, RoundedCornerShape(24.dp)),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Toggle Tab (Login / Register)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFFF1F5F9))
                                .padding(4.dp)
                        ) {
                            Button(
                                onClick = {
                                    isRegisterMode = false
                                    errorMessage = null
                                    onClearAuthError()
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (!isRegisterMode) BrandPurplePrimary else Color.Transparent,
                                    contentColor = if (!isRegisterMode) Color.White else TextSecondary
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f),
                                elevation = null
                            ) {
                                Text("Login", fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = {
                                    isRegisterMode = true
                                    errorMessage = null
                                    onClearAuthError()
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isRegisterMode) BrandPurplePrimary else Color.Transparent,
                                    contentColor = if (isRegisterMode) Color.White else TextSecondary
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f),
                                elevation = null
                            ) {
                                Text("Register", fontWeight = FontWeight.Bold)
                            }
                        }

                        // Error message banner
                        if (errorMessage != null) {
                            Spacer(modifier = Modifier.height(14.dp))
                            Surface(
                                color = Color(0xFFFEE2E2),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Default.ErrorOutline,
                                        contentDescription = "Error",
                                        tint = Color(0xFFDC2626),
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = errorMessage.orEmpty(),
                                        color = Color(0xFFB91C1C),
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        val inputColors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color(0xFF111111),
                            unfocusedTextColor = Color(0xFF111111),
                            cursorColor = Color(0xFF222222),
                            focusedPlaceholderColor = Color(0xFF777777),
                            unfocusedPlaceholderColor = Color(0xFF777777),
                            focusedLabelColor = BrandPurplePrimary,
                            unfocusedLabelColor = TextSecondary,
                            focusedBorderColor = BrandPurplePrimary,
                            unfocusedBorderColor = CardBorderSubtle
                        )

                        if (isRegisterMode) {
                            OutlinedTextField(
                                value = name,
                                onValueChange = {
                                    name = it
                                    errorMessage = null
                                    onClearAuthError()
                                },
                                label = { Text("Full Name") },
                                placeholder = { Text("e.g. Rahul Sharma") },
                                leadingIcon = {
                                    Icon(Icons.Default.Person, contentDescription = null, tint = BrandPurplePrimary)
                                },
                                singleLine = true,
                                colors = inputColors,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                        }

                        OutlinedTextField(
                            value = email,
                            onValueChange = {
                                email = it
                                errorMessage = null
                                onClearAuthError()
                            },
                            label = { Text("Email Address") },
                            placeholder = { Text("name@example.com") },
                            leadingIcon = {
                                Icon(Icons.Default.Mail, contentDescription = null, tint = BrandPurplePrimary)
                            },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                            singleLine = true,
                            colors = inputColors,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp)
                        )

                        if (isRegisterMode) {
                            Spacer(modifier = Modifier.height(12.dp))
                            OutlinedTextField(
                                value = phone,
                                onValueChange = {
                                    phone = it
                                    errorMessage = null
                                    onClearAuthError()
                                },
                                label = { Text("Mobile Number") },
                                placeholder = { Text("10-digit mobile number") },
                                leadingIcon = {
                                    Icon(Icons.Default.Phone, contentDescription = null, tint = BrandPurplePrimary)
                                },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                singleLine = true,
                                colors = inputColors,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp)
                            )

                            Spacer(modifier = Modifier.height(12.dp))
                            OutlinedTextField(
                                value = referralCode,
                                onValueChange = {
                                    referralCode = it.uppercase()
                                    errorMessage = null
                                    onClearAuthError()
                                },
                                label = { Text("Referral Code (Optional)") },
                                placeholder = { Text("e.g. EARN123") },
                                supportingText = { Text("Enter a referral code to get ₹5 (500 Coins) bonus!", fontSize = 11.sp, color = TextSecondary) },
                                leadingIcon = {
                                    Icon(
                                        painter = painterResource(id = R.drawable.ic_referral_gift),
                                        contentDescription = null,
                                        tint = Color.Unspecified,
                                        modifier = Modifier.size(20.dp)
                                    )
                                },
                                singleLine = true,
                                colors = inputColors,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = password,
                            onValueChange = {
                                password = it
                                errorMessage = null
                                onClearAuthError()
                            },
                            label = { Text(if (isRegisterMode) "Create Password" else "Password") },
                            placeholder = { Text("Minimum 6 characters") },
                            leadingIcon = {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = BrandPurplePrimary)
                            },
                            trailingIcon = {
                                IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                    Icon(
                                        imageVector = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                        contentDescription = if (passwordVisible) "Hide password" else "Show password",
                                        tint = Color.Gray
                                    )
                                }
                            },
                            visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            singleLine = true,
                            colors = inputColors,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp)
                        )

                        Spacer(modifier = Modifier.height(22.dp))

                        Button(
                            onClick = {
                                val trimmedEmail = email.trim()
                                val trimmedPassword = password.trim()
                                val emailPattern = android.util.Patterns.EMAIL_ADDRESS

                                if (isRegisterMode) {
                                    val trimmedName = name.trim()
                                    val trimmedPhone = phone.trim()
                                    val digitsOnly = trimmedPhone.filter { it.isDigit() }

                                    when {
                                        trimmedName.isBlank() -> {
                                            errorMessage = "Please enter your full name."
                                        }
                                        trimmedName.length < 2 -> {
                                            errorMessage = "Name must be at least 2 characters."
                                        }
                                        trimmedEmail.isBlank() -> {
                                            errorMessage = "Please enter your email address."
                                        }
                                        !emailPattern.matcher(trimmedEmail).matches() -> {
                                            errorMessage = "Please enter a valid email address."
                                        }
                                        trimmedPhone.isBlank() -> {
                                            errorMessage = "Please enter your mobile number."
                                        }
                                        digitsOnly.length < 10 -> {
                                            errorMessage = "Please enter a valid 10-digit mobile number."
                                        }
                                        trimmedPassword.isBlank() -> {
                                            errorMessage = "Please create a password."
                                        }
                                        trimmedPassword.length < 6 -> {
                                            errorMessage = "Password must be at least 6 characters."
                                        }
                                        else -> {
                                            errorMessage = null
                                            onLoginSuccess(
                                                trimmedEmail,
                                                trimmedName,
                                                trimmedPhone,
                                                trimmedPassword,
                                                referralCode.trim().takeIf { it.isNotBlank() }
                                            )
                                        }
                                    }
                                } else {
                                    when {
                                        trimmedEmail.isBlank() -> {
                                            errorMessage = "Please enter your email address."
                                        }
                                        !emailPattern.matcher(trimmedEmail).matches() -> {
                                            errorMessage = "Please enter a valid email address."
                                        }
                                        trimmedPassword.isBlank() -> {
                                            errorMessage = "Please enter your password."
                                        }
                                        trimmedPassword.length < 6 -> {
                                            errorMessage = "Password must be at least 6 characters."
                                        }
                                        else -> {
                                            errorMessage = null
                                            onLoginSuccess(
                                                trimmedEmail,
                                                "",
                                                "",
                                                trimmedPassword,
                                                null
                                            )
                                        }
                                    }
                                }
                            },
                            enabled = !isLoading,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = BrandPurplePrimary,
                                disabledContainerColor = BrandPurplePrimary.copy(alpha = 0.6f)
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("auth_submit_button")
                        ) {
                            if (isLoading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(24.dp),
                                    color = Color.White,
                                    strokeWidth = 2.5.dp
                                )
                            } else {
                                Text(
                                    text = if (isRegisterMode) "Register & Start Earning" else "Sign In",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
