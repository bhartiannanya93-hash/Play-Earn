package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.*
import com.example.ui.viewmodel.UserUiState

@Composable
fun WithdrawScreen(
    uiState: UserUiState,
    onBackClick: () -> Unit,
    onSubmitWithdrawal: (amount: Double, method: String, holder: String, upiOrAccount: String, ifsc: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val wallet = uiState.wallet
    val coins = wallet?.balanceCoins ?: 1255
    val availableBalance = coins / 100.0
    val minLimit = if (uiState.appConfig.minWithdrawalRupees > 0.0) uiState.appConfig.minWithdrawalRupees else 50.0
    val rate = if (uiState.appConfig.coinToRupeeRate > 0.0) uiState.appConfig.coinToRupeeRate else 0.01

    var amountText by remember { mutableStateOf("50") }
    var coinsText by remember { mutableStateOf("5000") }
    var selectedMethod by remember { mutableStateOf("UPI") } // "UPI" or "BANK"
    var upiId by remember { mutableStateOf("suman@okhdfcbank") }
    var accountHolder by remember { mutableStateOf("Suman Kumar") }
    var accountNumber by remember { mutableStateOf("") }
    var ifscCode by remember { mutableStateOf("") }

    val quickAmounts = listOf("50", "100", "200", "500")

    val withdrawInputColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = Color(0xFF000000),
        unfocusedTextColor = Color(0xFF000000),
        cursorColor = Color(0xFF222222),
        focusedPlaceholderColor = Color(0xFF666666),
        unfocusedPlaceholderColor = Color(0xFF666666),
        focusedLabelColor = Color(0xFF333333),
        unfocusedLabelColor = Color(0xFF666666),
        focusedBorderColor = BrandPurplePrimary,
        unfocusedBorderColor = CardBorder,
        focusedLeadingIconColor = BrandPurplePrimary,
        unfocusedLeadingIconColor = BrandPurplePrimary,
        focusedPrefixColor = BrandPurplePrimary,
        unfocusedPrefixColor = BrandPurplePrimary
    )

    val inputTextStyle = LocalTextStyle.current.copy(
        color = Color(0xFF000000),
        fontWeight = FontWeight.SemiBold,
        fontSize = 15.sp
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ScreenBackground)
            .testTag("withdraw_screen"),
        contentPadding = PaddingValues(bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Bar
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Color.White)
                        .testTag("withdraw_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = TextPrimary
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Text(
                    text = "Withdraw Funds",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = TextPrimary
                )
            }
        }

        // Available Balance Card
        item {
            Box(modifier = Modifier.padding(horizontal = 20.dp)) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = BrandPurplePrimary)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = "AVAILABLE BALANCE",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White.copy(alpha = 0.8f),
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = String.format(java.util.Locale.US, "₹%.2f", availableBalance),
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = RewardGoldLight,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Minimum withdrawal limit: ₹50.00 (5,000 Coins)",
                                fontSize = 12.sp,
                                color = RewardGoldLight,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }

        // Amount Input & Quick Chips
        item {
            Box(modifier = Modifier.padding(horizontal = 20.dp)) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "Enter Withdrawal Amount",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Dual Linked Amount & Coins Input Fields
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Amount in Rupees Field
                            OutlinedTextField(
                                value = amountText,
                                onValueChange = { input ->
                                    amountText = input.filter { ch -> ch.isDigit() || ch == '.' }
                                    val parsed = amountText.toDoubleOrNull() ?: 0.0
                                    coinsText = if (parsed > 0) (parsed / rate).toInt().toString() else ""
                                },
                                label = { Text("Amount (₹)", color = Color(0xFF666666)) },
                                placeholder = { Text("e.g. 50", color = Color(0xFF666666)) },
                                textStyle = inputTextStyle,
                                colors = withdrawInputColors,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("amount_input_field"),
                                leadingIcon = {
                                    Text(
                                        text = "₹",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = BrandPurplePrimary,
                                        modifier = Modifier.padding(start = 12.dp)
                                    )
                                },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                shape = RoundedCornerShape(14.dp)
                            )

                            // Coins Required Field
                            OutlinedTextField(
                                value = coinsText,
                                onValueChange = { input ->
                                    coinsText = input.filter { ch -> ch.isDigit() }
                                    val parsed = coinsText.toIntOrNull() ?: 0
                                    amountText = if (parsed > 0) {
                                        val rupees = parsed * rate
                                        if (rupees % 1.0 == 0.0) rupees.toInt().toString() else String.format(java.util.Locale.US, "%.2f", rupees)
                                    } else ""
                                },
                                label = { Text("Coins (🪙)", color = Color(0xFF666666)) },
                                placeholder = { Text("e.g. 5000", color = Color(0xFF666666)) },
                                textStyle = inputTextStyle,
                                colors = withdrawInputColors,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("coins_input_field"),
                                leadingIcon = {
                                    Icon(
                                        painter = painterResource(id = R.drawable.ic_coin_gold),
                                        contentDescription = null,
                                        tint = Color.Unspecified,
                                        modifier = Modifier
                                            .padding(start = 12.dp)
                                            .size(18.dp)
                                    )
                                },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                shape = RoundedCornerShape(14.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Quick Chips
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            quickAmounts.forEach { amt ->
                                val isSelected = amountText == amt
                                FilterChip(
                                    selected = isSelected,
                                    onClick = {
                                        amountText = amt
                                        val parsed = amt.toDoubleOrNull() ?: 0.0
                                        coinsText = (parsed / rate).toInt().toString()
                                    },
                                    label = { Text("₹$amt", fontWeight = FontWeight.Bold) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = BrandPurplePrimary,
                                        selectedLabelColor = Color.White,
                                        containerColor = Color(0xFFF1F5F9),
                                        labelColor = TextPrimary
                                    ),
                                    shape = RoundedCornerShape(10.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Payment Method Selector (UPI vs Bank)
        item {
            Box(modifier = Modifier.padding(horizontal = 20.dp)) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "Select Payment Method",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // UPI Option
                            Card(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { selectedMethod = "UPI" }
                                    .testTag("method_upi"),
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (selectedMethod == "UPI") Color(0xFFEDE9FE) else Color(0xFFF8FAFC)
                                ),
                                border = if (selectedMethod == "UPI") androidx.compose.foundation.BorderStroke(2.dp, BrandPurplePrimary) else null
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        painter = painterResource(id = R.drawable.ic_upi_payment),
                                        contentDescription = null,
                                        tint = Color.Unspecified,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "UPI",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = if (selectedMethod == "UPI") BrandPurplePrimary else TextPrimary
                                    )
                                }
                            }

                            // Bank Transfer Option
                            Card(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { selectedMethod = "BANK" }
                                    .testTag("method_bank"),
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (selectedMethod == "BANK") Color(0xFFEDE9FE) else Color(0xFFF8FAFC)
                                ),
                                border = if (selectedMethod == "BANK") androidx.compose.foundation.BorderStroke(2.dp, BrandPurplePrimary) else null
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        painter = painterResource(id = R.drawable.ic_bank_payment),
                                        contentDescription = null,
                                        tint = Color.Unspecified,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Bank",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = if (selectedMethod == "BANK") BrandPurplePrimary else TextPrimary
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Method Specific Fields
                        if (selectedMethod == "UPI") {
                            OutlinedTextField(
                                value = upiId,
                                onValueChange = { upiId = it.trim() },
                                label = { Text("UPI ID (e.g. yourname@okhdfcbank)", color = Color(0xFF666666)) },
                                placeholder = { Text("Enter your UPI ID", color = Color(0xFF666666)) },
                                textStyle = inputTextStyle,
                                colors = withdrawInputColors,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("upi_input_field"),
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp)
                            )
                        } else {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedTextField(
                                    value = accountHolder,
                                    onValueChange = { accountHolder = it },
                                    label = { Text("Account Holder Name", color = Color(0xFF666666)) },
                                    placeholder = { Text("Full name as per bank records", color = Color(0xFF666666)) },
                                    textStyle = inputTextStyle,
                                    colors = withdrawInputColors,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("holder_input_field"),
                                    singleLine = true,
                                    shape = RoundedCornerShape(14.dp)
                                )
                                OutlinedTextField(
                                    value = accountNumber,
                                    onValueChange = { accountNumber = it.filter { ch -> ch.isDigit() } },
                                    label = { Text("Bank Account Number", color = Color(0xFF666666)) },
                                    placeholder = { Text("Enter 9-18 digit account number", color = Color(0xFF666666)) },
                                    textStyle = inputTextStyle,
                                    colors = withdrawInputColors,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("account_input_field"),
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    shape = RoundedCornerShape(14.dp)
                                )
                                OutlinedTextField(
                                    value = ifscCode,
                                    onValueChange = { ifscCode = it.uppercase().trim() },
                                    label = { Text("IFSC Code (e.g. HDFC0001234)", color = Color(0xFF666666)) },
                                    placeholder = { Text("11-character IFSC code", color = Color(0xFF666666)) },
                                    textStyle = inputTextStyle,
                                    colors = withdrawInputColors,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("ifsc_input_field"),
                                    singleLine = true,
                                    shape = RoundedCornerShape(14.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Submit Button
        item {
            Box(modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
                Button(
                    onClick = {
                        val parsed = amountText.toDoubleOrNull() ?: 0.0
                        val coinsReq = (parsed / rate).toInt()
                        if (parsed < 50.0 || coinsReq < 5000) {
                            Toast.makeText(
                                context,
                                "Minimum withdrawal limit is ₹50.00 (5,000 Coins)",
                                Toast.LENGTH_SHORT
                            ).show()
                            return@Button
                        }
                        if (parsed > availableBalance) {
                            Toast.makeText(
                                context,
                                "Insufficient balance! Available: ₹${String.format(java.util.Locale.US, "%.2f", availableBalance)}",
                                Toast.LENGTH_SHORT
                            ).show()
                            return@Button
                        }
                        val identifier = if (selectedMethod == "UPI") upiId else accountNumber
                        onSubmitWithdrawal(parsed, selectedMethod, accountHolder, identifier, ifscCode)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RewardGreen),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("submit_withdrawal_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = Color.White
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "SUBMIT WITHDRAWAL REQUEST",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
