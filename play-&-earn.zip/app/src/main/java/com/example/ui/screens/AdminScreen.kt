package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.AppConfigEntity
import com.example.data.local.TaskEntity
import com.example.data.local.WithdrawalEntity
import com.example.ui.components.EmptyStateView
import com.example.ui.theme.*
import com.example.ui.viewmodel.RewardsViewModel
import com.example.ui.viewmodel.UserUiState
import kotlinx.coroutines.flow.collectLatest

@Composable
fun AdminScreen(
    viewModel: RewardsViewModel,
    uiState: UserUiState,
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isAuthenticated by remember { mutableStateOf(false) }
    var pinInput by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf(false) }

    val adminInputColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = Color(0xFF000000),
        unfocusedTextColor = Color(0xFF000000),
        cursorColor = Color(0xFF222222),
        focusedPlaceholderColor = Color(0xFF666666),
        unfocusedPlaceholderColor = Color(0xFF666666),
        focusedLabelColor = Color(0xFF333333),
        unfocusedLabelColor = Color(0xFF666666),
        focusedBorderColor = BrandPurplePrimary,
        unfocusedBorderColor = CardBorder
    )

    if (!isAuthenticated) {
        // Isolated Admin Authentication Gate
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(ScreenBackground)
                .statusBarsPadding()
                .padding(24.dp)
                .testTag("admin_auth_screen"),
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(12.dp, RoundedCornerShape(24.dp)),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(BrandPurplePrimary.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Security,
                            contentDescription = "Admin Security",
                            tint = BrandPurplePrimary,
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Admin Authentication",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = TextPrimary
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "Restricted Area. Enter Administrator Security PIN to proceed.",
                        fontSize = 13.sp,
                        color = TextSecondary,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = {
                            if (it.length <= 8) {
                                pinInput = it
                                pinError = false
                            }
                        },
                        label = { Text("Admin PIN / Password", color = Color(0xFF666666)) },
                        placeholder = { Text("Enter PIN", color = Color(0xFF666666)) },
                        textStyle = LocalTextStyle.current.copy(color = Color(0xFF000000), fontWeight = FontWeight.Bold),
                        colors = adminInputColors,
                        leadingIcon = {
                            Icon(imageVector = Icons.Outlined.Lock, contentDescription = null, tint = BrandPurplePrimary)
                        },
                        singleLine = true,
                        isError = pinError,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("admin_pin_input")
                    )

                    if (pinError) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Invalid Admin PIN. Access denied.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = onBackClick,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Back to App")
                        }

                        Button(
                            onClick = {
                                if (pinInput == "7788" || pinInput == "admin" || pinInput == "9876") {
                                    isAuthenticated = true
                                    pinError = false
                                } else {
                                    pinError = true
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BrandPurplePrimary),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("admin_verify_button")
                        ) {
                            Text("Authenticate", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        return
    }

    var selectedTab by remember { mutableStateOf("WITHDRAWALS") }
    val tabs = listOf("WITHDRAWALS", "TASKS", "GAMES", "SETTINGS")

    val allWithdrawals by viewModel.getAllWithdrawalsAdmin().collectAsState(initial = emptyList())
    val allTasks by viewModel.getAllTasksAdmin().collectAsState(initial = emptyList())
    val allUsers by viewModel.getAllUsersAdmin().collectAsState(initial = emptyList())

    val pendingWithdrawals = remember(allWithdrawals) {
        allWithdrawals.filter { it.status == "PENDING" }
    }

    var config by remember(uiState.appConfig) { mutableStateOf(uiState.appConfig) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ScreenBackground)
            .testTag("admin_screen"),
        contentPadding = PaddingValues(bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Bar
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Color.White)
                        .testTag("admin_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = TextPrimary
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Text(
                    text = "Admin Control Panel",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = TextPrimary
                )
            }
        }

        // Stats Overview Grid
        item {
            Box(modifier = Modifier.padding(horizontal = 20.dp)) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Platform Analytics",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            AdminStatChip("Total Users", "${allUsers.size}", BrandPurplePrimary)
                            AdminStatChip("Pending", "${pendingWithdrawals.size}", RewardGold)
                            AdminStatChip("Total Paid", "₹300.00", RewardGreenDark)
                        }
                    }
                }
            }
        }

        // Admin Navigation Tabs
        item {
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(tabs) { tab ->
                    val isSelected = selectedTab == tab
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedTab = tab },
                        label = {
                            Text(
                                text = tab.lowercase().replaceFirstChar { it.uppercase() },
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = BrandPurplePrimary,
                            selectedLabelColor = Color.White,
                            containerColor = Color.White,
                            labelColor = TextSecondary
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            }
        }

        // TAB 1: WITHDRAWALS MANAGEMENT
        if (selectedTab == "WITHDRAWALS") {
            if (allWithdrawals.isEmpty()) {
                item {
                    EmptyStateView(
                        title = "No Withdrawals",
                        message = "No pending or past withdrawal requests to show.",
                        iconRes = R.drawable.ic_wallet_card
                    )
                }
            } else {
                items(allWithdrawals) { item ->
                    Box(modifier = Modifier.padding(horizontal = 20.dp)) {
                        AdminWithdrawalCard(
                            withdrawal = item,
                            onApprove = { viewModel.adminProcessWithdrawal(item.id, "APPROVED", "Approved by Admin") },
                            onReject = { viewModel.adminProcessWithdrawal(item.id, "REJECTED", "Rejected: invalid details") },
                            onMarkPaid = { viewModel.adminProcessWithdrawal(item.id, "PAID", "Payment Transferred") }
                        )
                    }
                }
            }
        }

        // TAB 2: TASKS MANAGEMENT
        if (selectedTab == "TASKS") {
            items(allTasks) { task ->
                Box(modifier = Modifier.padding(horizontal = 20.dp)) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = task.title,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = task.description,
                                    fontSize = 12.sp,
                                    color = TextSecondary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Reward: +${task.rewardCoins} Coins (₹${task.rewardRupees}) • ${task.category}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = RewardGreenDark
                                )
                            }

                            Switch(
                                checked = task.isEnabled,
                                onCheckedChange = { isChecked ->
                                    viewModel.adminSaveTask(task.copy(isEnabled = isChecked))
                                }
                            )
                        }
                    }
                }
            }
        }

        // TAB 3: GAMES MANAGEMENT
        if (selectedTab == "GAMES") {
            item {
                Box(modifier = Modifier.padding(horizontal = 20.dp)) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            Text(
                                text = "Game Reward Settings",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )

                            // Tap Coin
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("Tap Coin Game", fontWeight = FontWeight.Bold)
                                    Text("Reward: ${config.tapCoinRewardCoins} Coins / Level", fontSize = 12.sp, color = TextSecondary)
                                }
                                Switch(
                                    checked = config.isTapCoinEnabled,
                                    onCheckedChange = {
                                        config = config.copy(isTapCoinEnabled = it)
                                        viewModel.adminUpdateConfig(config)
                                    }
                                )
                            }

                            // Color Match
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("Color Match Game", fontWeight = FontWeight.Bold)
                                    Text("Reward: ${config.colorMatchRewardCoins} Coins / Level", fontSize = 12.sp, color = TextSecondary)
                                }
                                Switch(
                                    checked = config.isColorMatchEnabled,
                                    onCheckedChange = {
                                        config = config.copy(isColorMatchEnabled = it)
                                        viewModel.adminUpdateConfig(config)
                                    }
                                )
                            }

                            // Catch Candy
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("Catch Candy Game", fontWeight = FontWeight.Bold)
                                    Text("Reward: ${config.catchCandyRewardCoins} Coins / Level", fontSize = 12.sp, color = TextSecondary)
                                }
                                Switch(
                                    checked = config.isCatchCandyEnabled,
                                    onCheckedChange = {
                                        config = config.copy(isCatchCandyEnabled = it)
                                        viewModel.adminUpdateConfig(config)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // TAB 4: APP SETTINGS
        if (selectedTab == "SETTINGS") {
            item {
                Box(modifier = Modifier.padding(horizontal = 20.dp)) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            Text(
                                text = "Economy & Limits",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )

                            // Min Withdrawal
                            OutlinedTextField(
                                value = config.minWithdrawalRupees.toString(),
                                onValueChange = {
                                    val v = it.toDoubleOrNull() ?: config.minWithdrawalRupees
                                    config = config.copy(minWithdrawalRupees = v)
                                },
                                label = { Text("Minimum Withdrawal Limit (₹)", color = Color(0xFF666666)) },
                                textStyle = LocalTextStyle.current.copy(color = Color(0xFF000000), fontWeight = FontWeight.Bold),
                                colors = adminInputColors,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            )

                            // Referral Bonus
                            OutlinedTextField(
                                value = config.referralBonusRupees.toString(),
                                onValueChange = {
                                    val v = it.toDoubleOrNull() ?: config.referralBonusRupees
                                    config = config.copy(referralBonusRupees = v)
                                },
                                label = { Text("Referral Bonus Reward (₹)", color = Color(0xFF666666)) },
                                textStyle = LocalTextStyle.current.copy(color = Color(0xFF000000), fontWeight = FontWeight.Bold),
                                colors = adminInputColors,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            )

                            // Coin to Rupee Rate
                            OutlinedTextField(
                                value = config.coinToRupeeRate.toString(),
                                onValueChange = {
                                    val v = it.toDoubleOrNull() ?: config.coinToRupeeRate
                                    config = config.copy(coinToRupeeRate = v)
                                },
                                label = { Text("Coin-to-Rupee Rate (0.01 = 100 Coins / ₹1)", color = Color(0xFF666666)) },
                                textStyle = LocalTextStyle.current.copy(color = Color(0xFF000000), fontWeight = FontWeight.Bold),
                                colors = adminInputColors,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            )

                            // Save Button
                            Button(
                                onClick = { viewModel.adminUpdateConfig(config) },
                                colors = ButtonDefaults.buttonColors(containerColor = BrandPurplePrimary),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Save Configuration Changes", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminStatChip(title: String, value: String, color: Color) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(color.copy(alpha = 0.1f))
            .padding(horizontal = 14.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = title, fontSize = 11.sp, color = TextSecondary)
        Text(text = value, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = color)
    }
}

@Composable
fun AdminWithdrawalCard(
    withdrawal: WithdrawalEntity,
    onApprove: () -> Unit,
    onReject: () -> Unit,
    onMarkPaid: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = withdrawal.userName,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "${withdrawal.paymentMethod}: ${withdrawal.upiOrAccount}",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                }

                Text(
                    text = String.format(java.util.Locale.US, "₹%.2f", withdrawal.amountRupees),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = BrandPurplePrimary
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (withdrawal.status == "PENDING") {
                    Button(
                        onClick = onApprove,
                        colors = ButtonDefaults.buttonColors(containerColor = RewardGreen),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Approve", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = onReject,
                        colors = ButtonDefaults.buttonColors(containerColor = RewardRed),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Reject", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                } else if (withdrawal.status == "APPROVED") {
                    Button(
                        onClick = onMarkPaid,
                        colors = ButtonDefaults.buttonColors(containerColor = BrandBlue),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Mark as Paid", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFFF1F5F9))
                            .padding(8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Status: ${withdrawal.status}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary
                        )
                    }
                }
            }
        }
    }
}
