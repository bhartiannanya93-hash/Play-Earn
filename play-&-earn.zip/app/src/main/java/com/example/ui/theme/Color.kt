package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Bento Grid Palette & Brand Colors
val BrandPurplePrimary = Color(0xFF6C5CE7)
val BrandPurpleSecondary = Color(0xFFA29BFE)
val BrandPurpleDark = Color(0xFF4A00E0)
val BrandPurpleLight = Color(0xFFEEF2FF)
val BrandIndigo = Color(0xFF4F46E5)
val BrandBlue = Color(0xFF3B82F6)

// Accent & Earning Colors
val RewardGreen = Color(0xFF22C55E)
val RewardGreenDark = Color(0xFF16A34A)
val RewardGreenLight = Color(0xFFDCFCE7)
val RewardGold = Color(0xFFF59E0B)
val RewardGoldLight = Color(0xFFFEF3C7)
val RewardOrange = Color(0xFFFF8E53)
val RewardCoral = Color(0xFFFF6B6B)
val RewardOrangeLight = Color(0xFFFFF7ED)
val RewardRed = Color(0xFFEF4444)

// Bento Canvas, Surface & Border Colors
val SurfaceWhite = Color(0xFFFFFFFF)
val ScreenBackground = Color(0xFFF3F4F9)
val CardBorder = Color(0xFFF1F5F9)
val CardBorderSubtle = Color(0xFFE2E8F0)
val CardShadowColor = Color(0x140F172A)
val BentoBoxBg = Color(0xFFF8FAFC)

// Slate Typography Palette
val TextPrimary = Color(0xFF0F172A)     // slate-900
val TextSecondary = Color(0xFF64748B)   // slate-500
val TextMuted = Color(0xFF94A3B8)       // slate-400
val TextDark = Color(0xFF1E293B)        // slate-800
val TextOnGradient = Color(0xFFFFFFFF)


