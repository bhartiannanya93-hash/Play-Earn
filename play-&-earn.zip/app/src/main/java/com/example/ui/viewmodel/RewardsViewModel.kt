package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.*
import com.example.data.repository.RewardsRepository
import com.example.ui.components.BottomTab
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

sealed class ActiveScreen {
    object Main : ActiveScreen()
    object Withdraw : ActiveScreen()
    object Referral : ActiveScreen()
    object Admin : ActiveScreen()
    object Auth : ActiveScreen()
    data class GamePlay(val gameId: String) : ActiveScreen()
}

data class UserUiState(
    val currentUser: UserEntity? = null,
    val wallet: WalletEntity? = null,
    val tasks: List<TaskEntity> = emptyList(),
    val gamesProgress: List<GameProgressEntity> = emptyList(),
    val withdrawals: List<WithdrawalEntity> = emptyList(),
    val transactions: List<TransactionEntity> = emptyList(),
    val notifications: List<NotificationEntity> = emptyList(),
    val unreadNotifCount: Int = 0,
    val appConfig: AppConfigEntity = AppConfigEntity(),
    val currentTab: BottomTab = BottomTab.GAME,
    val activeScreen: ActiveScreen = ActiveScreen.Auth,
    val isShowingRewardedAd: Boolean = false,
    val pendingAdRewardCoins: Int = 5,
    val onAdClaimSuccess: (() -> Unit)? = null,
    val snackbarMessage: String? = null,
    val isLoading: Boolean = false,
    val authErrorMessage: String? = null
) {
    val totalCoinsEarned: Int
        get() {
            val creditTxns = transactions.filter { it.isCredit }
            return if (creditTxns.isNotEmpty()) {
                creditTxns.sumOf { it.amountCoins }
            } else {
                wallet?.balanceCoins ?: 1255
            }
        }

    val totalEarnedRupees: Double
        get() = totalCoinsEarned / 100.0

    val todayCoinsEarned: Int
        get() {
            val creditTxns = transactions.filter { it.isCredit }
            if (creditTxns.isNotEmpty()) {
                val cal = java.util.Calendar.getInstance().apply {
                    set(java.util.Calendar.HOUR_OF_DAY, 0)
                    set(java.util.Calendar.MINUTE, 0)
                    set(java.util.Calendar.SECOND, 0)
                    set(java.util.Calendar.MILLISECOND, 0)
                }
                val todayStart = cal.timeInMillis
                return creditTxns.filter { it.timestamp >= todayStart }.sumOf { it.amountCoins }
            }
            return 0
        }

    val todayEarnedRupees: Double
        get() = todayCoinsEarned / 100.0
}

class RewardsViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = RewardsRepository(AppDatabase.getDatabase(application))

    private val _uiState = MutableStateFlow(UserUiState())
    val uiState: StateFlow<UserUiState> = _uiState.asStateFlow()

    private val currentUserId = MutableStateFlow("user_default_1")

    init {
        // Start Firestore Real-Time Listener on active user
        viewModelScope.launch {
            currentUserId.collect { id ->
                repository.startRealtimeListeners(id)
            }
        }

        // Check if there is an active Firebase Auth session to auto-restore
        viewModelScope.launch {
            val autoUser = repository.getAutoLoginUser()
            if (autoUser != null) {
                currentUserId.value = autoUser.id
                _uiState.update { it.copy(currentUser = autoUser, activeScreen = ActiveScreen.Main) }
            }
        }

        // Collect User Data
        viewModelScope.launch {
            currentUserId.flatMapLatest { id ->
                repository.getUser(id)
            }.collect { user ->
                _uiState.update { it.copy(currentUser = user) }
            }
        }

        // Collect Wallet
        viewModelScope.launch {
            currentUserId.flatMapLatest { id ->
                repository.getWallet(id)
            }.collect { wallet ->
                _uiState.update { it.copy(wallet = wallet) }
            }
        }

        // Collect Tasks
        viewModelScope.launch {
            repository.getActiveTasks().collect { tasks ->
                _uiState.update { it.copy(tasks = tasks) }
            }
        }

        // Collect Games Progress
        viewModelScope.launch {
            currentUserId.flatMapLatest { id ->
                repository.getAllGamesProgress(id)
            }.collect { progress ->
                _uiState.update { it.copy(gamesProgress = progress) }
            }
        }

        // Collect Withdrawals
        viewModelScope.launch {
            currentUserId.flatMapLatest { id ->
                repository.getWithdrawalsByUser(id)
            }.collect { withdrawals ->
                _uiState.update { it.copy(withdrawals = withdrawals) }
            }
        }

        // Collect Transactions
        viewModelScope.launch {
            currentUserId.flatMapLatest { id ->
                repository.getTransactions(id)
            }.collect { txns ->
                _uiState.update { it.copy(transactions = txns) }
            }
        }

        // Collect Notifications
        viewModelScope.launch {
            currentUserId.flatMapLatest { id ->
                repository.getNotifications(id)
            }.collect { notifs ->
                _uiState.update { it.copy(notifications = notifs) }
            }
        }

        viewModelScope.launch {
            currentUserId.flatMapLatest { id ->
                repository.getUnreadCount(id)
            }.collect { count ->
                _uiState.update { it.copy(unreadNotifCount = count) }
            }
        }

        // Collect App Configuration
        viewModelScope.launch {
            repository.getAppConfig().collect { config ->
                if (config != null) {
                    _uiState.update { it.copy(appConfig = config) }
                }
            }
        }
    }

    // ----------------------------------------------------
    // Navigation & Tabs
    // ----------------------------------------------------
    fun selectTab(tab: BottomTab) {
        _uiState.update { it.copy(currentTab = tab, activeScreen = ActiveScreen.Main) }
    }

    fun navigateTo(screen: ActiveScreen) {
        _uiState.update { it.copy(activeScreen = screen) }
    }

    fun navigateBack() {
        _uiState.update { it.copy(activeScreen = ActiveScreen.Main) }
    }

    // ----------------------------------------------------
    // Tasks & Rewards
    // ----------------------------------------------------
    fun claimTask(taskId: String) {
        val userId = _uiState.value.currentUser?.id ?: return
        viewModelScope.launch {
            val result = repository.claimTaskReward(userId, taskId)
            result.onSuccess { msg ->
                showSnackbar(msg)
            }.onFailure { err ->
                showSnackbar(err.message ?: "Failed to claim task")
            }
        }
    }

    // ----------------------------------------------------
    // Game Completion & Rewarded Ads
    // ----------------------------------------------------
    fun completeGameLevel(
        gameId: String,
        levelCompleted: Int,
        score: Int,
        claimedWithAd: Boolean,
        customRewardCoins: Int? = null,
        onDone: ((coinsAwarded: Int) -> Unit)? = null
    ) {
        val userId = _uiState.value.currentUser?.id ?: return
        viewModelScope.launch {
            val awardedCoins = customRewardCoins ?: when (gameId) {
                "arrow_escape", "tap_coin" -> (1..50).random()
                else -> null
            }
            repository.completeGameLevel(
                userId = userId,
                gameId = gameId,
                levelCompleted = levelCompleted,
                score = score,
                watchAdRewardClaimed = claimedWithAd,
                customRewardCoins = awardedCoins
            )
            if (claimedWithAd) {
                showSnackbar("Reward credited to your wallet! 🎉")
            }
            if (awardedCoins != null) {
                onDone?.invoke(awardedCoins)
            }
        }
    }

    private var hasEarnedRewardInCurrentAd: Boolean = false

    fun launchRewardedAd(coins: Int, onClaimSuccess: () -> Unit) {
        hasEarnedRewardInCurrentAd = false
        _uiState.update {
            it.copy(
                isShowingRewardedAd = true,
                pendingAdRewardCoins = coins,
                onAdClaimSuccess = onClaimSuccess
            )
        }
    }

    fun onUserEarnedReward(coins: Int) {
        hasEarnedRewardInCurrentAd = true
    }

    fun onRewardedAdDismissed(rewardEarned: Boolean = false) {
        val verifiedReward = rewardEarned && hasEarnedRewardInCurrentAd
        val onClaim = _uiState.value.onAdClaimSuccess
        _uiState.update { it.copy(isShowingRewardedAd = false, onAdClaimSuccess = null) }
        hasEarnedRewardInCurrentAd = false

        if (verifiedReward) {
            onClaim?.invoke()
        }
    }

    fun onRewardedAdCompleted() {
        hasEarnedRewardInCurrentAd = true
    }

    // ----------------------------------------------------
    // Withdrawals
    // ----------------------------------------------------
    fun requestWithdrawal(
        amount: Double,
        method: String,
        accountHolder: String,
        upiOrAccount: String,
        ifsc: String,
        onSuccess: () -> Unit
    ) {
        val user = _uiState.value.currentUser ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val result = repository.requestWithdrawal(
                userId = user.id,
                userName = user.name,
                amountRupees = amount,
                paymentMethod = method,
                accountHolder = accountHolder,
                upiOrAccount = upiOrAccount,
                ifsc = ifsc
            )
            _uiState.update { it.copy(isLoading = false) }
            result.onSuccess {
                showSnackbar("Withdrawal of ₹$amount requested successfully! Status: PENDING")
                onSuccess()
            }.onFailure { err ->
                showSnackbar(err.message ?: "Withdrawal failed")
            }
        }
    }

    // ----------------------------------------------------
    // Admin Actions
    // ----------------------------------------------------
    fun getAllUsersAdmin(): Flow<List<UserEntity>> = repository.getAllUsers()
    fun getAllWithdrawalsAdmin(): Flow<List<WithdrawalEntity>> = repository.getAllWithdrawals()
    fun getAllTasksAdmin(): Flow<List<TaskEntity>> = repository.getAllTasks()
    fun getAllTransactionsAdmin(): Flow<List<TransactionEntity>> = repository.getAllTransactions()

    fun adminProcessWithdrawal(id: String, status: String, note: String) {
        viewModelScope.launch {
            val result = repository.processWithdrawalAdmin(id, status, note)
            result.onSuccess {
                showSnackbar("Withdrawal $status successfully")
            }.onFailure { err ->
                showSnackbar(err.message ?: "Operation failed")
            }
        }
    }

    fun adminSaveTask(task: TaskEntity) {
        viewModelScope.launch {
            repository.saveOrUpdateTask(task)
            showSnackbar("Task updated successfully")
        }
    }

    fun adminDeleteTask(taskId: String) {
        viewModelScope.launch {
            repository.deleteTask(taskId)
            showSnackbar("Task removed")
        }
    }

    fun adminUpdateConfig(config: AppConfigEntity) {
        viewModelScope.launch {
            repository.updateAppConfig(config)
            showSnackbar("App settings updated")
        }
    }

    // ----------------------------------------------------
    // Notifications & Messages
    // ----------------------------------------------------
    fun markAllNotificationsRead() {
        val userId = _uiState.value.currentUser?.id ?: return
        viewModelScope.launch {
            repository.markNotificationsAsRead(userId)
        }
    }

    fun showSnackbar(message: String) {
        _uiState.update { it.copy(snackbarMessage = message) }
    }

    fun dismissSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }

    fun clearAuthError() {
        _uiState.update { it.copy(authErrorMessage = null) }
    }

    // ----------------------------------------------------
    // Authentication
    // ----------------------------------------------------
    fun login(email: String, name: String, phone: String, password: String = "", refCode: String? = null) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, authErrorMessage = null) }
            val result = repository.registerOrLoginUser(name, email, phone, password, refCode)
            _uiState.update { it.copy(isLoading = false) }
            result.onSuccess { user ->
                currentUserId.value = user.id
                _uiState.update { it.copy(currentUser = user, activeScreen = ActiveScreen.Main, authErrorMessage = null) }
                showSnackbar("Welcome, ${user.name}!")
            }.onFailure { error ->
                val errorMsg = error.message ?: "Invalid email or password"
                _uiState.update { it.copy(authErrorMessage = errorMsg) }
                showSnackbar(errorMsg)
                try {
                    android.widget.Toast.makeText(getApplication(), errorMsg, android.widget.Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    // Ignore if toast cannot be displayed
                }
            }
        }
    }

    fun logout() {
        repository.logout()
        _uiState.update { it.copy(currentUser = null, activeScreen = ActiveScreen.Auth) }
    }

    override fun onCleared() {
        super.onCleared()
        repository.stopRealtimeListeners()
    }
}
