package com.example.ads

/**
 * Centralized Google AdMob configuration.
 * Contains standard Google AdMob Test Ad Unit IDs.
 * Replace with your Production IDs before publishing to Google Play Store.
 */
object AdConfig {
    // Official Google AdMob Sample Test App ID
    const val ADMOB_APP_ID = "ca-app-pub-3940256099942544~3347511713"

    // Official Google AdMob Rewarded Video Test Ad Unit ID
    const val REWARDED_AD_UNIT_ID = "ca-app-pub-3940256099942544/5224354917"

    // Official Google AdMob Interstitial Test Ad Unit ID
    const val INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-3940256099942544/1033173712"

    // Official Google AdMob Banner Test Ad Unit ID
    const val BANNER_AD_UNIT_ID = "ca-app-pub-3940256099942544/6300978111"

    // Standard Full-Length Rewarded Video Duration in seconds (Google AdMob standard 15s)
    const val REWARDED_AD_DURATION_SECONDS = 15
}
